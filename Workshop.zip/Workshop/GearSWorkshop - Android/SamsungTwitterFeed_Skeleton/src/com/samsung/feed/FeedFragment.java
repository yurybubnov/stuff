/*
 * Copyright (C) 2014 Samsung Electronics. All Rights Reserved.
 * Source code is licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and limitations under the License.
 *
 * IMPORTANT LICENSE NOTE:
 * The IMAGES AND RESOURCES are licensed under the Creative Commons BY-NC-SA 3.0
 * License (http://creativecommons.org/licenses/by-nc-sa/3.0/).
 * The source code is allows commercial re-use, but IMAGES and RESOURCES forbids it.
 */

package com.samsung.feed;

import android.app.Dialog;
import android.app.ListFragment;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import twitter4j.FilterQuery;
import twitter4j.MediaEntity;
import twitter4j.Query;
import twitter4j.QueryResult;
import twitter4j.StallWarning;
import twitter4j.Status;
import twitter4j.StatusDeletionNotice;
import twitter4j.StatusListener;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.TwitterStream;
import twitter4j.TwitterStreamFactory;
import twitter4j.auth.AccessToken;
import twitter4j.conf.ConfigurationBuilder;

import com.samsung.android.sdk.SsdkUnsupportedException;
import com.samsung.android.sdk.richnotification.Srn;
import com.samsung.android.sdk.richnotification.SrnAction;
import com.samsung.android.sdk.richnotification.SrnAction.CallbackIntent;
import com.samsung.android.sdk.richnotification.SrnImageAsset;
import com.samsung.android.sdk.richnotification.SrnRichNotification;
import com.samsung.android.sdk.richnotification.SrnRichNotification.AlertType;
import com.samsung.android.sdk.richnotification.SrnRichNotification.PopupType;
import com.samsung.android.sdk.richnotification.SrnRichNotificationManager;
import com.samsung.android.sdk.richnotification.actions.SrnHostAction;
import com.samsung.android.sdk.richnotification.actions.SrnRemoteInputAction;
import com.samsung.android.sdk.richnotification.actions.SrnRemoteInputAction.InputModeFactory;
import com.samsung.android.sdk.richnotification.actions.SrnRemoteInputAction.KeyboardInputMode.KeyboardType;
import com.samsung.android.sdk.richnotification.actions.SrnRemoteLaunchAction;
import com.samsung.android.sdk.richnotification.templates.SrnStandardTemplate;
import com.samsung.android.sdk.richnotification.templates.SrnStandardTemplate.HeaderSizeType;
import com.samsung.tool.DemoStatus;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * Creates an instance ListFragment that contains rows for 15 FeedRowItems.
 * Handles the initial query of tweets by a given hashtag. Listens for updates
 * by a given hashtag and checks for a given username to trigger a push
 * notification to the wearable attached. Allows the user to create a new Tweet
 * and uploads that tweet to their Twitter account.
 * 
 * @author k.schaller
 *
 */
public class FeedFragment extends ListFragment {
	/** Used to bundle Android Wear notifications */
	final static String GROUP_TWEETS = "group_tweets";

	private ListView mListView;
	private TwitterListAdapter mAdapter;
	
	/** Rich Notification variables */
	SrnRichNotificationManager mRichNotificationManager;
	SrnRichNotification mRichNotification;
	SrnStandardTemplate mStandardTemplate;

	ArrayList<FeedRowItem> mItems = new ArrayList<FeedRowItem>();

	/** View variables */
	ImageView mProgressSpinner, arrow;
	EditText mTweetText;
	Dialog mDialog;
	SharedPreferences mPref;
	TextView signInText, retryText;
	RelativeLayout newTweet;
	Button retry;

	/** Twitter4j variables */
	TwitterStream mTwitterStream;

	/**
	 * Constructor class
	 */
	public FeedFragment() {

	}

	/**
	 * Allows fragment instance to be retained across Activity re-creation. Done
	 * in the onCreate because this is only called once.
	 */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
	}

	/**
	 * Inflates the view and assign view variables. Creates a new instance of
	 * TwitterListAdapter and sets it as the ListView's adapter.
	 */
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_main, container,
				false);

		/** Get shared preferences */
		mPref = getActivity().getPreferences(0);

		mListView = (ListView) rootView.findViewById(android.R.id.list);
		mProgressSpinner = (ImageView) rootView.findViewById(R.id.progress_spinner);
		newTweet = (RelativeLayout) rootView.findViewById(R.id.send_tweet_container);
		signInText = (TextView) rootView.findViewById(R.id.sign_into_twitter_text);
		arrow = (ImageView) rootView.findViewById(R.id.arrow);
		newTweet.setOnClickListener(new Tweet());
		retryText = (TextView) rootView.findViewById(R.id.retry_text);
		retry = (Button) rootView.findViewById(R.id.retry);

		mAdapter = new TwitterListAdapter(getActivity(), mItems);
		mListView.setAdapter(mAdapter);
		return rootView;
	}

	/**
	 * Executes the async task GetTweets(). Attempts to intialize an instance of
	 * Srn to check if Rich Notifications are supported. Creates a new instance
	 * of SrnRichNotificationManager and starts it.
	 */
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		/** Checks to see if the user is logged in. If so, execute GetTweets() to
		 *  load a list of Tweets; otherwise, hide the progress spinner & new Tweet
		 *  views and show the sign-in text and the sign-in arrow */
		if(this.getArguments() == null) {
			new GetTweets().execute();
		} else if(this.getArguments().getString("STATUS").equalsIgnoreCase("no_connection")) {
			mProgressSpinner.setVisibility(View.GONE);
			newTweet.setVisibility(View.GONE);
			signInText.setVisibility(View.GONE);	
			arrow.setVisibility(View.GONE);
			retryText.setVisibility(View.VISIBLE);
			retry.setVisibility(View.VISIBLE);
			retry.setOnClickListener(new Retry());
		} else if(this.getArguments().getString("STATUS").equalsIgnoreCase("logged_in")){
			mProgressSpinner.setVisibility(View.GONE);
			newTweet.setVisibility(View.GONE);
			signInText.setVisibility(View.VISIBLE);	
			arrow.setVisibility(View.VISIBLE);
		}

		/**
		 * Code to check if the phone is a Samsung device running at least API
		 * 19
		 */
		Srn srn = new Srn();
		try {
			/** Initialize an instance of Srn. */
			srn.initialize(getActivity());
		} catch (SsdkUnsupportedException e) {
			/**
			 * VENDOR_NOT_SUPPORTED: The device is not a Samsung device
			 * DEVICE_NOT_SUPPORTED: The device does not support the Srn package
			 **/
			if (e.getType() == SsdkUnsupportedException.VENDOR_NOT_SUPPORTED)
				Toast.makeText(getActivity(), "Not a Samsung device", Toast.LENGTH_SHORT).show();
			else if (e.getType() == SsdkUnsupportedException.DEVICE_NOT_SUPPORTED)
				Toast.makeText(getActivity(), "Only supports Android 4.2.2 and up", Toast.LENGTH_SHORT).show();
			else
				Toast.makeText(getActivity(), "Failed", Toast.LENGTH_SHORT).show();
		}

		/** Create and start the SrnRichNotificationManager */
		mRichNotificationManager = new SrnRichNotificationManager(getActivity());
		mRichNotificationManager.start();
		
		/** Setup listener for notification button */
		MainActivity.sNotificationContainer.setOnClickListener(new Notify());
	}

	/**
	 * Closes the TwitterStream and stops the SrnRichNotificationManager
	 */
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (mTwitterStream != null) {
			/** Close the TwitterStream started in updateListener() */
			mTwitterStream.shutdown();
		}
		/** Stop Notification Manager */
		mRichNotificationManager.stop();
	}

	/**
	 * Creates a click listener that checks the connection.
	 */
	private class Retry implements OnClickListener {
		@Override
		public void onClick(View v) {
			/** Check for data connection */
			ConnectivityManager cm = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
			NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
			boolean isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();
				
			if(isConnected) {
				getActivity().recreate();
			} else {
				Toast.makeText(MainActivity.sContext, "No Network Connection. Press the Twitter icon when you have connection.", Toast.LENGTH_LONG).show();
			}
		}
	}
	
	/**
	 * Listens for a click event. When received it displays the input dialog to
	 * create and send a new Tweet. Sets a click listener that executes the
	 * async task SendTweet().
	 * 
	 * @author k.schaller
	 *
	 */
	private class Tweet implements OnClickListener {
		@Override
		public void onClick(View v) {
			/** Create and show Dialog */
			mDialog = new Dialog(getActivity());
			mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
			mDialog.setContentView(R.layout.tweet_dialog);
			mTweetText = (EditText) mDialog.findViewById(R.id.tweet_text_field);
			ImageView post_tweet = (ImageView) mDialog.findViewById(R.id.post_tweet);
			post_tweet.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					new SendTweet().execute();
				}
			});
			mDialog.show();
		}
	}
	
	/**
	 * Listens for a click event. When received it displays the input dialog to
	 * create and send a new Tweet. Sets a click listener that executes the
	 * async task SendTweet().
	 * 
	 * @author k.schaller
	 *
	 */
	public class Notify implements OnClickListener {
		@Override
		public void onClick(final View v) {
			ImageView icon = (ImageView) v.findViewById(R.id.notification_image);
			icon.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.ic_action_accept));
			sendNotification(DemoStatus.sStatus, BitmapFactory.decodeResource(getResources(), R.drawable.sdc_logo), null);
			Handler myHandler = new Handler();
			myHandler.postDelayed(new Runnable() {
				@Override
				public void run() {
					ImageView icon = (ImageView) v.findViewById(R.id.notification_image);
					icon.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.open_on_gear));
				} 
			}, 2500);
		}
	}

	/**
	 * Attempts to post the new Status to the user's Twitter account on a
	 * separate thread.
	 * 
	 * @author k.schaller
	 *
	 */
	private class SendTweet extends AsyncTask<String, String, String> {
		ProgressDialog progress;
		String tweetText;

		/**
		 * Display a ProgressDialog
		 */
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			progress = new ProgressDialog(getActivity());
			progress.setMessage("Posting Tweet...");
			progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			progress.setIndeterminate(true);
			tweetText = mTweetText.getText().toString();
			progress.show();
		}

		/**
		 * Create a new Twitter instance. Check for previously stored Consumer
		 * key, Consumer secret, Access token, and Access token secret. If
		 * found, create a new instance of TwitterFactory; otherwise, use the
		 * variable created in parent activity. Attempts to send tweet with the
		 * user's text and the hashtag "#SDC2014".
		 */
		@Override
		protected String doInBackground(String... params) {
			Twitter twitter;
			if (mPref.getBoolean("LOGGED_IN_CHECK", false)) {
				ConfigurationBuilder builder = new ConfigurationBuilder();
				builder.setOAuthConsumerKey(mPref.getString("CONSUMER_KEY", ""));
				builder.setOAuthConsumerSecret(mPref.getString("CONSUMER_SECRET", ""));
				AccessToken accessToken = new AccessToken(mPref.getString("ACCESS_TOKEN", ""), 
						mPref.getString("ACCESS_TOKEN_SECRET", ""));
				twitter = new TwitterFactory(builder.build())
				.getInstance(accessToken);
			} else {
				twitter = MainActivity.sTwitter;
			}

			try {
				twitter4j.Status response = twitter.updateStatus(tweetText + " #SDC2014");
				return response.toString();
			} catch (TwitterException e) {
				e.printStackTrace();
			}
			return null;
		}

		/**
		 * Dismiss the ProgressDialog and the tweet Dialog. Display a Toast
		 * showing confirmation or error.
		 */
		@Override
		protected void onPostExecute(String res) {
			if (res != null) {
				progress.dismiss();
				Toast.makeText(getActivity(), "Tweet Posted", Toast.LENGTH_SHORT).show();
				mDialog.dismiss();
			} else {
				progress.dismiss();
				Toast.makeText(getActivity(), "Tweet Did Not Post", Toast.LENGTH_SHORT).show();
				mDialog.dismiss();
			}
		}
	}

	/**
	 * Attempts to retrieve the 15 latest tweets with a given hashtag
	 * "#SDC2014". If successful, for each tweet a new FeedRowItem is created
	 * with the supplied data and the ListView's adapter is notified of a data
	 * set change.
	 * 
	 * @author k.schaller
	 *
	 */
	private class GetTweets extends
	AsyncTask<String, String, ArrayList<FeedRowItem>> {
		Twitter twitter;

		/**
		 * Start rotation animation. Check to see if OAuth keys/secrets have
		 * been stored. If so, create a new TwitterFactory; otherwise, use the
		 * instance from the parent Activity.
		 */
		@Override
		protected void onPreExecute() {
			Animation a = AnimationUtils.loadAnimation(getActivity(), R.anim.progress_anim);
			mProgressSpinner.startAnimation(a);

			if (mPref.getBoolean("LOGGED_IN_CHECK", false)) {
				ConfigurationBuilder cb = new ConfigurationBuilder();
				cb.setDebugEnabled(true)
				  .setOAuthConsumerKey(mPref.getString("CONSUMER_KEY", ""))
				  .setOAuthConsumerSecret(mPref.getString("CONSUMER_SECRET", ""))
				  .setOAuthAccessToken(mPref.getString("ACCESS_TOKEN", ""))
				  .setOAuthAccessTokenSecret(mPref.getString("ACCESS_TOKEN_SECRET", ""));

				TwitterFactory tf = new TwitterFactory(cb.build());
				twitter = tf.getInstance();
			} else {
				twitter = MainActivity.sTwitter;
			}
		}

		/**
		 * Attempts to query Twitter for the hashtag "#SDC2014" and retrieve the
		 * latest 15 results. If this is successful, for each tweet: pull down
		 * the user's profile image and if there's a photo attached to the tweet
		 * download that as well, and create a FeedRowItem.
		 */
		@Override
		protected ArrayList<FeedRowItem> doInBackground(String... params) {
			try {
				Query query = new Query("#SDC2014");
				query.setCount(15);
				QueryResult result;

				result = twitter.search(query);
				List<twitter4j.Status> tweets = result.getTweets();
				for (twitter4j.Status status : tweets) {
					Bitmap profilePhoto = null;
					Bitmap attachedPhoto = null;
					String URL = "";

					for (MediaEntity entity : status.getMediaEntities()) {
						if (entity.getType().equalsIgnoreCase("photo"))
							URL = entity.getDisplayURL();
					}
					try {
						Bitmap downloadPhoto = BitmapFactory.
								decodeStream((InputStream) new URL(status.getUser().getOriginalProfileImageURL()).getContent());
						ByteArrayOutputStream outProfile = new ByteArrayOutputStream();
						downloadPhoto.compress(Bitmap.CompressFormat.PNG, 25, outProfile);
						downloadPhoto.recycle();
						profilePhoto = BitmapFactory.decodeStream(new ByteArrayInputStream(outProfile.toByteArray()));

						ByteArrayOutputStream outPhoto = new ByteArrayOutputStream();
						attachedPhoto = BitmapFactory.decodeStream((InputStream) new URL(URL).getContent());
						attachedPhoto.compress(Bitmap.CompressFormat.PNG, 25,outPhoto);
						attachedPhoto = BitmapFactory.decodeStream(new ByteArrayInputStream(outPhoto.toByteArray()));
					} catch (MalformedURLException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}

					long minutesSince = Calendar.getInstance()
							.getTimeInMillis()
							- status.getCreatedAt().getTime();
					minutesSince = ((minutesSince / 1000) / 60);
					String timeString = Long.toString(minutesSince) + "m";
					
					if(minutesSince >= (60 * 24)) {
						DecimalFormat format = new DecimalFormat("#");
						timeString= format.format((minutesSince / 60.0000) / 24.0000) + "d";
					} else if (minutesSince >= 60) {
						timeString = Integer.toString((int)minutesSince/60) + "h";
					}
					
					if (attachedPhoto != null)
						mItems.add(new FeedRowItem(status.getId(), status.getFavoriteCount(), 
												status.getInReplyToStatusId(), 
												status.getInReplyToUserId(), 
												status.getRetweetCount(), 
												status.isFavorited(), status.isRetweeted(),
												status.getUser().getName(), 
												status.getUser().getScreenName(),
												profilePhoto, status.getText(),
												timeString, attachedPhoto, true));
					else {
						mItems.add(new FeedRowItem(status.getId(), status.getFavoriteCount(), 
												status.getInReplyToStatusId(), 
												status.getInReplyToUserId(), 
												status.getRetweetCount(), 
												status.isFavorited(), status.isRetweeted(),
												status.getUser().getName(), 
												status.getUser().getScreenName(),
												profilePhoto, status.getText(),
												timeString, false));
					}
				}
			} catch (TwitterException e) {
				e.printStackTrace();
				Looper.prepare();
				Toast.makeText(getActivity(),"Couldn't find tweets for: #SDC2014",Toast.LENGTH_SHORT).show();
			}
			return mItems;
		}

		/**
		 * Stop the roatation animation and hide the progress spinner. Tell the
		 * ListView's adapter that the data set has changed. Call the
		 * updateListener() method to create a status listener for any new
		 * incoming tweets.
		 */
		@Override
		protected void onPostExecute(ArrayList<FeedRowItem> res) {
			super.onPostExecute(res);
			mProgressSpinner.clearAnimation();
			mProgressSpinner.setVisibility(View.GONE);
			mAdapter.notifyDataSetChanged();
			updateListener();
		}
	}

	/**
	 * Creates a new TwitterStreamFactory, sets the OAuthConsumer and
	 * OAuthAccess tokens, and creates an instance of StatusListener that
	 * listens for a given hashtag "#SDC2014". Creates a local notification and
	 * pushes another to any connected wearable for all tweets from the user
	 * "SDC_2014" that include the given hashtag.
	 */
	public void updateListener() {
		/**
		 * Check to make sure that the TwitterStream hasn't been created already
		 */
		if (mTwitterStream == null) {
			/** Create the TwitterStream and set it's OAuth tokens/secrets */
			mTwitterStream = new TwitterStreamFactory(
					new ConfigurationBuilder().setJSONStoreEnabled(true).build()).getInstance();

			mTwitterStream.setOAuthConsumer(mPref.getString("CONSUMER_KEY", ""),
					mPref.getString("CONSUMER_SECRET", ""));
			AccessToken token = new AccessToken(mPref.getString("ACCESS_TOKEN",""), 
					mPref.getString("ACCESS_TOKEN_SECRET", ""));
			mTwitterStream.setOAuthAccessToken(token);

			/** Create a StatusListener */
			StatusListener listener = new StatusListener() {
				/**
				 * When a tweet comes in download and compress the profile photo
				 * and any photos associated with the tweet, create a new
				 * FeedRowItem, remove an item from the bottom of the list to
				 * keep memory in bounds, notify the ListView's adapter that the
				 * data set has changed, and check if the user sending the tweet
				 * is "SDC_2014". If so, call sendNotification() to create and
				 * send a Android and SrnRichNotification.
				 */
				@Override
				public void onStatus(Status status) {
					Bitmap profilePhoto = null;
					Bitmap attachedPhoto = null;
					String URL = "";

					for (MediaEntity entity : status.getMediaEntities()) {
						if (entity.getType().equalsIgnoreCase("photo"))
							URL = entity.getMediaURL();
					}

					try {
						Bitmap downloadPhoto = BitmapFactory.decodeStream((InputStream) 
								new URL(status.getUser().getOriginalProfileImageURL()).getContent());
						ByteArrayOutputStream outProfile = new ByteArrayOutputStream();
						downloadPhoto.compress(Bitmap.CompressFormat.PNG, 25,outProfile);
						downloadPhoto.recycle();
						profilePhoto = BitmapFactory.decodeStream(new ByteArrayInputStream(outProfile.toByteArray()));

						ByteArrayOutputStream outPhoto = new ByteArrayOutputStream();
						attachedPhoto = BitmapFactory.decodeStream((InputStream) new URL(URL).getContent());
						attachedPhoto.compress(Bitmap.CompressFormat.PNG, 25,outPhoto);
						attachedPhoto = BitmapFactory.decodeStream(new ByteArrayInputStream(outPhoto.toByteArray()));
					} catch (MalformedURLException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}

					long minutesSince = Calendar.getInstance().getTimeInMillis() - status.getCreatedAt().getTime();
					minutesSince = ((minutesSince / 1000) / 60);
					String timeString = Long.toString(minutesSince) + "m";
					
					if(minutesSince >= (60 * 24)) {
						DecimalFormat format = new DecimalFormat("#");
						timeString= format.format((minutesSince / 60.0000) / 24.0000) + "d";
					} else if (minutesSince >= 60) {
						//DecimalFormat format = new DecimalFormat("##");	
						timeString = Integer.toString((int)minutesSince/60) + "h";
					}

					if (attachedPhoto != null) {
						mItems.add(0, new FeedRowItem(status.getId(), status.getFavoriteCount(), 
												status.getInReplyToStatusId(), 
												status.getInReplyToUserId(), 
												status.getRetweetCount(), 
												status.isFavorited(), status.isRetweetedByMe(), 
												status.getUser().getName(), 
												status.getUser().getScreenName(), 
												profilePhoto, status.getText(), 
												timeString, attachedPhoto, true));
					} else {
						mItems.add(0, new FeedRowItem(status.getId(), status.getFavoriteCount(), 
										status.getInReplyToStatusId(), 
										status.getInReplyToUserId(), 
										status.getRetweetCount(), 
										status.isFavorited(), status.isRetweetedByMe(), 
										status.getUser().getName(), 
										status.getUser().getScreenName(), 
										profilePhoto, status.getText(), 
										timeString, false));
					}

					mItems.remove(mItems.size() - 1);
					mListView.post(new Runnable() {
						public void run() {
							mAdapter.notifyDataSetChanged();
						}
					});

					if (status.getUser().getScreenName().equalsIgnoreCase("SDC_2014")) {
						if (attachedPhoto != null) {
							sendNotification(status, profilePhoto,attachedPhoto);
						} else {
							sendNotification(status, profilePhoto, null);
						}
					}
				}

				@Override
				public void onException(Exception arg0) {

				}

				@Override
				public void onDeletionNotice(StatusDeletionNotice arg0) {

				}

				@Override
				public void onScrubGeo(long arg0, long arg1) {

				}

				/**
				 * Display a toast is the user is reaching the limit warning for
				 * queries.
				 */
				@Override
				public void onStallWarning(StallWarning arg0) {
					try {
						Toast.makeText(getActivity(), "Thread limit warning", Toast.LENGTH_SHORT).show();
						Thread.sleep(250);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

				@Override
				public void onTrackLimitationNotice(int arg0) {

				}

			};

			/** Add the StatusListener created above to the TwitterStream */
			mTwitterStream.addListener(listener);

			/** Set the hashtag that should be tracked */
			FilterQuery query = new FilterQuery();
			query.track(new String[] { "#SDC2014" });
			mTwitterStream.filter(query);
		}
	}

	/**
	 * Creates an Android notification and a Rich Notification, associates the
	 * two, and sends them to their respective notification managers.
	 * 
	 * @param status
	 * @param profilePhoto
	 * @param attachedPhoto
	 */
	private void sendNotification(Status status, Bitmap profilePhoto, Bitmap attachedPhoto) {
		/** Start Exercise 1 */
		/** Create a unique ID */
		Date now = new Date();
		int notificationId = (int) now.getTime();

		/** Android Notification */
		/** Intent to launch the application when the notification is clicked */
		Intent viewIntent = new Intent(getActivity(), MainActivity.class);
		viewIntent.setAction(Intent.ACTION_MAIN);
		viewIntent.addCategory(Intent.CATEGORY_LAUNCHER);
		
		PendingIntent viewPendingIntent = PendingIntent.getActivity(getActivity(), 0, viewIntent, 0);
		
		/** Builder to create the notification with parameters */
		NotificationCompat.Builder builder = new NotificationCompat.Builder(getActivity())
		/** Set the small icon that appears in the notification bar */
		.setSmallIcon(R.drawable.sdc_logo)
		/** Set the title of the notification */
		.setContentTitle(status.getUser().getName())
		/** Set the body of the notification */
		.setContentText(status.getText())
		/** Set the icon seen within the notification tray */
		.setLargeIcon(profilePhoto)
		/** Set the style so the notification can be expanded into multi-line */
		.setStyle(new NotificationCompat.BigTextStyle()
		/** Set the body when the notification is expanded */
		.bigText(status.getText()))
		/** Set the Intent created above */
		.setContentIntent(viewPendingIntent);


		/** Build the notification */
		Notification notification = builder.build();
		/**
		 * Create the notification manager. Using NotificationManagerCompat to
		 * be compatible with Android Wear
		 */
		NotificationManagerCompat notificationManager = NotificationManagerCompat.from(getActivity());
		/**
		 * Set flags to show the lights when received and dismiss the
		 * notification when clicked
		 */
		notification.flags = Notification.FLAG_SHOW_LIGHTS | Notification.FLAG_AUTO_CANCEL;
		/** Set the lights and sound properties to the device defaults */
		notification.defaults = Notification.DEFAULT_ALL;
		
		/** Send the notification with a unique ID */
		notificationManager.notify(notificationId, notification);
		/** End Exercise 1 */
		
		
		/** Rich Notification */		
		
		/** Adding actions to SrnRichNotification */
		
		/** Alert the notification manager to send the notification */

	}
}
