/*
 * Copyright (C) 2014 Samsung Electronics. All Rights Reserved.
 * Source code is licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and limitations under the License.
 *
 * IMPORTANT LICENSE NOTE:
 * The IMAGES AND RESOURCES are licensed under the Creative Commons BY-NC-SA 3.0
 * License (http://creativecommons.org/licenses/by-nc-sa/3.0/).
 * The source code is allows commercial re-use, but IMAGES and RESOURCES forbids it.
 */

package com.samsung.tool;

import twitter4j.GeoLocation;
import twitter4j.HashtagEntity;
import twitter4j.MediaEntity;
import twitter4j.Place;
import twitter4j.RateLimitStatus;
import twitter4j.Scopes;
import twitter4j.Status;
import twitter4j.SymbolEntity;
import twitter4j.URLEntity;
import twitter4j.User;
import twitter4j.UserMentionEntity;

import java.util.Date;

/**
 * Creates a new instance of the Status object with hard coded 
 * values for the User (under getUser) and the Tweet Text (under getText).
 * Everything else is set to the default values.
 * 
 * @author k.schaller
 *
 */
public class DemoStatus {
	public static Status sStatus = new Status() {
		private static final long serialVersionUID = 1L;

		@Override
		public UserMentionEntity[] getUserMentionEntities() {
			return null;
		}

		@Override
		public URLEntity[] getURLEntities() {
			return null;
		}

		@Override
		public SymbolEntity[] getSymbolEntities() {
			return null;
		}

		@Override
		public MediaEntity[] getMediaEntities() {
			return null;
		}

		@Override
		public HashtagEntity[] getHashtagEntities() {
			return null;
		}

		@Override
		public MediaEntity[] getExtendedMediaEntities() {
			return null;
		}

		@Override
		public RateLimitStatus getRateLimitStatus() {
			return null;
		}

		@Override
		public int getAccessLevel() {
			return 0;
		}

		@Override
		public int compareTo(Status another) {
			return 0;
		}

		@Override
		public boolean isTruncated() {
			return false;
		}

		@Override
		public boolean isRetweetedByMe() {
			return false;
		}

		@Override
		public boolean isRetweeted() {
			return false;
		}

		@Override
		public boolean isRetweet() {
			return false;
		}

		@Override
		public boolean isPossiblySensitive() {
			return false;
		}

		@Override
		public boolean isFavorited() {
			return false;
		}

		/**
		 * Creates a new demo User with hardcoded values for
		 * screen name (under getScreenName) and name (under getName).
		 * Everything else is set to the default values.
		 */
		@Override
		public User getUser() {
			User user = new User() {
				private static final long serialVersionUID = 2L;

				@Override
				public RateLimitStatus getRateLimitStatus() {
					return null;
				}

				@Override
				public int getAccessLevel() {
					return 0;
				}

				@Override
				public int compareTo(User another) {
					return 0;
				}

				@Override
				public boolean isVerified() {
					return false;
				}

				@Override
				public boolean isTranslator() {
					return false;
				}

				@Override
				public boolean isShowAllInlineMedia() {
					return false;
				}

				@Override
				public boolean isProtected() {
					return false;
				}

				@Override
				public boolean isProfileUseBackgroundImage() {
					return false;
				}

				@Override
				public boolean isProfileBackgroundTiled() {
					return false;
				}

				@Override
				public boolean isGeoEnabled() {
					return false;
				}

				@Override
				public boolean isFollowRequestSent() {
					return false;
				}

				@Override
				public boolean isDefaultProfileImage() {
					return false;
				}

				@Override
				public boolean isDefaultProfile() {
					return false;
				}

				@Override
				public boolean isContributorsEnabled() {
					return false;
				}

				@Override
				public int getUtcOffset() {
					return 0;
				}

				@Override
				public URLEntity getURLEntity() {
					return null;
				}

				@Override
				public String getURL() {
					return null;
				}

				@Override
				public String getTimeZone() {
					return null;
				}

				@Override
				public int getStatusesCount() {
					return 0;
				}

				@Override
				public Status getStatus() {
					return null;
				}

				@Override
				public String getScreenName() {
					return "SDC_2014";
				}

				@Override
				public String getProfileTextColor() {
					return null;
				}

				@Override
				public String getProfileSidebarFillColor() {
					return null;
				}

				@Override
				public String getProfileSidebarBorderColor() {
					return null;
				}

				@Override
				public String getProfileLinkColor() {
					return null;
				}

				@Override
				public String getProfileImageURLHttps() {
					return null;
				}

				@Override
				public String getProfileImageURL() {
					return null;
				}

				@Override
				public String getProfileBannerURL() {
					return null;
				}

				@Override
				public String getProfileBannerRetinaURL() {
					return null;
				}

				@Override
				public String getProfileBannerMobileURL() {
					return null;
				}

				@Override
				public String getProfileBannerMobileRetinaURL() {
					return null;
				}

				@Override
				public String getProfileBannerIPadURL() {
					return null;
				}

				@Override
				public String getProfileBannerIPadRetinaURL() {
					return null;
				}

				@Override
				public String getProfileBackgroundImageUrlHttps() {
					return null;
				}

				@Override
				public String getProfileBackgroundImageURL() {
					return null;
				}

				@Override
				public String getProfileBackgroundColor() {
					return null;
				}

				@Override
				public String getOriginalProfileImageURLHttps() {
					return null;
				}

				@Override
				public String getOriginalProfileImageURL() {
					return null;
				}

				@Override
				public String getName() {
					return "Demo User";
				}

				@Override
				public String getMiniProfileImageURLHttps() {
					return null;
				}

				@Override
				public String getMiniProfileImageURL() {
					return null;
				}

				@Override
				public String getLocation() {
					return null;
				}

				@Override
				public int getListedCount() {
					return 0;
				}

				@Override
				public String getLang() {
					return null;
				}

				@Override
				public long getId() {
					return 0;
				}

				@Override
				public int getFriendsCount() {
					return 0;
				}

				@Override
				public int getFollowersCount() {
					return 0;
				}

				@Override
				public int getFavouritesCount() {
					return 0;
				}

				@Override
				public URLEntity[] getDescriptionURLEntities() {
					return null;
				}

				@Override
				public String getDescription() {
					return null;
				}

				@Override
				public Date getCreatedAt() {
					return null;
				}

				@Override
				public String getBiggerProfileImageURLHttps() {
					return null;
				}

				@Override
				public String getBiggerProfileImageURL() {
					return null;
				}
			};
			return user;
		}

		@Override
		public String getText() {
			return "Demo Tweet message";
		}

		@Override
		public String getSource() {
			return null;
		}

		@Override
		public Scopes getScopes() {
			return null;
		}

		@Override
		public Status getRetweetedStatus() {
			return null;
		}

		@Override
		public int getRetweetCount() {
			return 0;
		}

		@Override
		public Place getPlace() {
			return null;
		}

		@Override
		public String getLang() {
			return null;
		}

		@Override
		public long getInReplyToUserId() {
			return 0;
		}

		@Override
		public long getInReplyToStatusId() {
			return 0;
		}

		@Override
		public String getInReplyToScreenName() {
			return null;
		}

		@Override
		public long getId() {
			return 0;
		}

		@Override
		public GeoLocation getGeoLocation() {
			return null;
		}

		@Override
		public int getFavoriteCount() {
			return 0;
		}

		@Override
		public long getCurrentUserRetweetId() {
			return 0;
		}

		@Override
		public Date getCreatedAt() {
			return null;
		}

		@Override
		public long[] getContributors() {
			return null;
		}
	};
}
