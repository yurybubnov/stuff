/*
 * Copyright (C) 2014 Samsung Electronics. All Rights Reserved.
 * Source code is licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and limitations under the License.
 *
 * IMPORTANT LICENSE NOTE:
 * The IMAGES AND RESOURCES are licensed under the Creative Commons BY-NC-SA 3.0
 * License (http://creativecommons.org/licenses/by-nc-sa/3.0/).
 * The source code is allows commercial re-use, but IMAGES and RESOURCES forbids it.
 */

package com.samsung.tool;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.ImageView;

/**
 * Creates a rounded image of the supplied drawable and adds a colored circle
 * frame around the photo.
 * 
 * @author k.schaller
 *
 */
public class RoundedImageView extends ImageView {

	/**
	 * Public constructor class.
	 * 
	 * @param context
	 */
	public RoundedImageView(Context context) {
		super(context);
	}

	/**
	 * Public constructor class.
	 * 
	 * @param context
	 * @param attrs
	 */
	public RoundedImageView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	/**
	 * Public constructor class.
	 * 
	 * @param context
	 * @param attrs
	 * @param defStyle
	 */
	public RoundedImageView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	/**
	 * Draws the bitmap onto the supplied canvas after it's been rounded and the
	 * border has been applied.
	 */
	@Override
	protected void onDraw(Canvas canvas) {
		Drawable mDrawable = getDrawable();

		if (mDrawable == null) {
			return;
		}

		if (getWidth() == 0 || getHeight() == 0) {
			return;
		}
		Bitmap mBitmapFromDrawable = ((BitmapDrawable) mDrawable).getBitmap();
		/** Make a mutable copy of the Bitmap */
		Bitmap mBitmap = mBitmapFromDrawable
				.copy(Bitmap.Config.ARGB_8888, true);

		int mWidth = getWidth();

		/** Call getCroppedBitmap() to receive the bitmap rounded and framed */
		Bitmap roundBitmap = getCroppedBitmap(mBitmap, mWidth);
		/** Draw the returned bitmap onto the canvas at position 0,0 */
		canvas.drawBitmap(roundBitmap, 0, 0, null);
	}

	/**
	 * Converts a supplied Bitmap to a circle with the given radius, and adds a
	 * border to it.
	 * 
	 * @param bmp
	 * @param radius
	 * @return
	 */
	public static Bitmap getCroppedBitmap(Bitmap bmp, int radius) {
		Bitmap mSourceBmp;
		/**
		 * Check the height and width. If the photo's height/width exceed the
		 * radius, created a scaled Bitmap using the radius for dimensions;
		 * otherwise, set the new Bitmap equal to the supplied Bitmap
		 */
		if (bmp.getWidth() != radius || bmp.getHeight() != radius)
			mSourceBmp = Bitmap.createScaledBitmap(bmp, radius, radius, false);
		else
			mSourceBmp = bmp;
		/** Create a new Bitmap from the previously created Bitmap */
		Bitmap mOutputBitmap = Bitmap.createBitmap(mSourceBmp.getWidth(), mSourceBmp.getHeight(), Config.ARGB_8888);

		Canvas mCanvas = new Canvas(mOutputBitmap);
		Paint mPaint = new Paint();
		Rect mRect = new Rect(0, 0, mSourceBmp.getWidth(), mSourceBmp.getHeight());

		mPaint.setAntiAlias(true);
		mPaint.setFilterBitmap(true);
		mPaint.setDither(true);
		mCanvas.drawARGB(0, 0, 0, 0);
		mPaint.setColor(Color.parseColor("#BAB399"));
		/** Draw the Circle onto the Canvas */
		mCanvas.drawCircle(mSourceBmp.getWidth() / 2 + 0.7f,mSourceBmp.getHeight() / 2 + 0.7f,
				mSourceBmp.getWidth() / 2 + 0.1f, mPaint);
		mPaint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
		/** Draw the Bitmap onto the Canvas */
		mCanvas.drawBitmap(mSourceBmp, mRect, mRect, mPaint);

		return mOutputBitmap;
	}

}