/*
 * Copyright (C) 2014 Samsung Electronics. All Rights Reserved.
 * Source code is licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and limitations under the License.
 *
 * IMPORTANT LICENSE NOTE:
 * The IMAGES AND RESOURCES are licensed under the Creative Commons BY-NC-SA 3.0
 * License (http://creativecommons.org/licenses/by-nc-sa/3.0/).
 * The source code is allows commercial re-use, but IMAGES and RESOURCES forbids it.
 */

package com.samsung.sap;

import android.content.Intent;
import android.net.Uri;
import android.os.Binder;
import android.os.IBinder;
import android.widget.Toast;

import com.samsung.android.sdk.SsdkUnsupportedException;
import com.samsung.android.sdk.accessory.SA;
import com.samsung.android.sdk.accessory.SAAgent;
import com.samsung.android.sdk.accessory.SAPeerAgent;
import com.samsung.android.sdk.accessory.SASocket;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;

/**
 * Allows communication between Samsung phone (host) and Samsung Gear
 * (accessory) to send and receive information.
 * 
 * @author k.schaller
 *
 */
public class ProviderService extends SAAgent {
	public static final String TAG = "ProviderService";
	/** Channel needs to be unique to talk to watch */
	public static final int ACCESSORY_CHANNEL_ID = 104;

	/** Creates a local binder responsible for returning agent service */
	private final IBinder mIBinder = new LocalBinder();

	/** HashMap containing the current connections */
	HashMap<Integer, ProviderConnection> connectionMap = null;

	/**
	 * Public constructor class.
	 */
	public ProviderService() {
		super(TAG, ProviderConnection.class);
	}

	/**
	 * Typically used for debugging.
	 */
	@Override
	protected void onFindPeerAgentResponse(SAPeerAgent arg0, int arg1) {

	}

	/**
	 * Displays a message to the user that indicates the status of the device's
	 * connection.
	 */
	@Override
	protected void onServiceConnectionResponse(SASocket thisConnection,
			int result) {
		/** The device connects successfully */
		if (result == CONNECTION_SUCCESS) {
			if (thisConnection != null) {
				/**
				 * Create new ProviderConnection and set it to the current
				 * connection cast to a ProviderConnection role
				 */
				ProviderConnection myConnection = (ProviderConnection) thisConnection;

				if (connectionMap == null) {
					connectionMap = new HashMap<Integer, ProviderConnection>();
				}

				/** Use the current time to help create unique identifier */
				myConnection.mConnectionID = (int) (System.currentTimeMillis() & 255);
				/** Put current connection into HashMap */
				connectionMap.put(myConnection.mConnectionID, myConnection);

				Toast.makeText(getBaseContext(), "CONNECTION ESTABLISHED",
						Toast.LENGTH_SHORT).show();
			} else {
				Toast.makeText(getBaseContext(), "SASocket object is null",
						Toast.LENGTH_SHORT).show();
			}
		} else if (result == CONNECTION_ALREADY_EXIST) {
			/** The device is already connected */
			Toast.makeText(getBaseContext(), "CONNECTION ALREADY EXISTS",
					Toast.LENGTH_SHORT).show();
		} else {
			/** Something went wrong */
			Toast.makeText(getBaseContext(),
					"onServiceConnectionResponse error = " + result,
					Toast.LENGTH_SHORT).show();
		}
	}

	/**
	 * Returns the an IBinder.
	 */
	@Override
	public IBinder onBind(Intent intent) {
		return mIBinder;
	}

	/**
	 * Attempts to initialize the accessory object.
	 */
	@Override
	public void onCreate() {
		super.onCreate();

		SA mAccessory = new SA();
		try {
			mAccessory.initialize(this);
		} catch (SsdkUnsupportedException e) {
			e.printStackTrace();
		} catch (Exception e1) {
			e1.printStackTrace();
			stopSelf();
		}
	}

	/**
	 * When another device requests connection to host device send SAPeerAgent
	 * to accepServiceConnectionRequest().
	 */
	@Override
	public void onServiceConnectionRequested(SAPeerAgent peerAgent) {
		acceptServiceConnectionRequest(peerAgent);
	}

	/**
	 * Returns ProviderService class.
	 * 
	 * @author k.schaller
	 *
	 */
	public class LocalBinder extends Binder {
		public ProviderService getService() {
			return ProviderService.this;
		}
	}

	/**
	 * Instance of a connection between a service provider & a service consumer
	 */
	public class ProviderConnection extends SASocket {
		private int mConnectionID;

		/**
		 * Public constructor class.
		 */
		public ProviderConnection() {
			super(ProviderConnection.class.getName());
		}

		/**
		 * Shows an error message. Primarily used for debugging.
		 */
		@Override
		public void onError(int channelID, String errorString, int errorCode) {
			Toast.makeText(getBaseContext(),
					"ERROR : " + errorString + " | " + errorCode,
					Toast.LENGTH_SHORT).show();
		}

		/**
		 * Launched a web page with the data received from the accessory to the
		 * host device.
		 */
		@Override
		public void onReceive(int channelID, byte[] data) {
			String url = "";
			/** Attempt to create a new String from the byte array. */
			try {
				url = new String(data, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			/** Parse the string into a uri */
			Uri webpage = Uri.parse(url);
			/** Launch a webpage using the uri created above */
			Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			if (intent.resolveActivity(getPackageManager()) != null) {
				startActivity(intent);
			}
		}

		/**
		 * Remove the connection from the HashMap when the connection is lost.
		 */
		@Override
		protected void onServiceConnectionLost(int connectionID) {
			if (connectionMap != null) {
				connectionMap.remove(connectionID);
			}
		}

	}
}
