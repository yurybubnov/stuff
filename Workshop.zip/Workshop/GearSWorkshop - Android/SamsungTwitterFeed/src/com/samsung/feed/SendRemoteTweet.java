/*
 * Copyright (C) 2014 Samsung Electronics. All Rights Reserved.
 * Source code is licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and limitations under the License.
 *
 * IMPORTANT LICENSE NOTE:
 * The IMAGES AND RESOURCES are licensed under the Creative Commons BY-NC-SA 3.0
 * License (http://creativecommons.org/licenses/by-nc-sa/3.0/).
 * The source code is allows commercial re-use, but IMAGES and RESOURCES forbids it.
 */

package com.samsung.feed;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.RemoteInput;
import android.util.Log;
import android.widget.Toast;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.auth.AccessToken;
import twitter4j.conf.ConfigurationBuilder;

/**
 * Called by the wearable device. Creates a new status update based on the text sent by the user in the Intent.
 * @author k.schaller
 *
 */
public class SendRemoteTweet extends Activity {
	SharedPreferences mPref;
	String mString;
	
	/**
	 * Places the OAuth secrets and tokens into SharesPrefences. Stores the string passed in by the user to a global variable.
	 */
	@SuppressLint("NewApi")
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(getIntent().getStringExtra("extra_voice_reply") != null) {
			Bundle remoteInput = RemoteInput.getResultsFromIntent(getIntent());
	        if (remoteInput != null) {
	            mString = remoteInput.getCharSequence("extra_voice_reply").toString();
	        }
		} else {
			mString = getIntent().getStringExtra("extra_action_data");
		}
		mPref = getPreferences(0);
		SharedPreferences.Editor edit = mPref.edit();
		edit.putString("CONSUMER_KEY", getIntent().getStringExtra("CONSUMER_KEY"));
		edit.putString("CONSUMER_SECRET", getIntent().getStringExtra("CONSUMER_SECRET"));
		edit.putString("ACCESS_TOKEN", getIntent().getStringExtra("ACCESS_TOKEN"));
		edit.putString("ACCESS_TOKEN_SECRET", getIntent().getStringExtra("ACCESS_TOKEN_SECRET"));
		edit.commit();
	}
	
	/**
	 * Starts the SendTweetAsync() async task passing in the user's string.
	 */
	@Override
	public void onResume() {
		super.onResume();
		
		new SendTweetAsync().execute(mString);
	}
	
	/**
	 * Create a new Twitter instance from the SharedPreferences. Attempts to send tweet with the
	 * user's text and the hashtag "#SDC2014". Display a Toast showing confirmation or error.
	 * @author k.schaller
	 *
	 */
	private class SendTweetAsync extends AsyncTask<String, String, String> {
		/**
		 * Create a new Twitter instance from the SharedPreferences. Attempts to send tweet with the
		 * user's text and the hashtag "#SDC2014".
		 */
		@Override
		protected String doInBackground(String... params) {
			Twitter twitter;
			ConfigurationBuilder builder = new ConfigurationBuilder();
			builder.setOAuthConsumerKey(mPref.getString("CONSUMER_KEY", ""));
			builder.setOAuthConsumerSecret(mPref.getString("CONSUMER_SECRET", ""));
			AccessToken accessToken = new AccessToken(mPref.getString("ACCESS_TOKEN", ""), mPref.getString("ACCESS_TOKEN_SECRET", ""));
			twitter = new TwitterFactory(builder.build()).getInstance(accessToken);

			try {
				twitter4j.Status response = twitter.updateStatus(params[0] + " #SDC2014");
				return response.toString();
			} catch (TwitterException e) {
				e.printStackTrace();
				Log.d("TAG", e.getErrorMessage());
			}
			return null;
		}

		/**
		 * Display a Toast showing confirmation or error.
		 */
		@Override
		protected void onPostExecute(String res) {
			if (res != null) {
				Toast.makeText(MainActivity.sContext, "Tweet Posted", Toast.LENGTH_SHORT).show();
				finish();
			} else {
				Toast.makeText(MainActivity.sContext, "Tweet Did Not Post", Toast.LENGTH_SHORT).show();
				finish();
			}
		}
	}
}
