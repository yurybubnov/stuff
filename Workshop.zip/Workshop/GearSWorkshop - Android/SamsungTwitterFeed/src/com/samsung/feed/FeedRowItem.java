/*
 * Copyright (C) 2014 Samsung Electronics. All Rights Reserved.
 * Source code is licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and limitations under the License.
 *
 * IMPORTANT LICENSE NOTE:
 * The IMAGES AND RESOURCES are licensed under the Creative Commons BY-NC-SA 3.0
 * License (http://creativecommons.org/licenses/by-nc-sa/3.0/).
 * The source code is allows commercial re-use, but IMAGES and RESOURCES forbids it.
 */

package com.samsung.feed;

import android.app.Fragment;
import android.graphics.Bitmap;

/**
 * Creates a FeedRowItem. Contains all getters and setters for the FeedRowItem
 * object.
 * 
 * @author k.schaller
 *
 */
public class FeedRowItem extends Fragment {
	private String mTwitterName, mTwitterHandle, mTweetContent, mTweetTime;
	private Bitmap mProfilePicture, mContentImage = null;
	private Boolean mHasContentImage = false, mIsFavorited, mIsRetweeted;
	private long mStatusId, mReplyTweetId, mReplyUserId;
	private int mFavoriteCount, mRetweetCount;

	/**
	 * Public constructor class
	 * 
	 * @param statusId
	 * @param favoriteCount
	 * @param replyTweetId
	 * @param replyUserId
	 * @param retweetCount
	 * @param isFavorited
	 * @param isRetweeted
	 * @param twitterName
	 * @param twitterHandle
	 * @param profilePicture
	 * @param tweetContent
	 * @param tweetTime
	 * @param hasContentImage
	 */
	public FeedRowItem(long statusId, int favoriteCount, long replyTweetId, long replyUserId, int retweetCount, boolean isFavorited,
			boolean isRetweeted, String twitterName, String twitterHandle, Bitmap profilePicture, String tweetContent, String tweetTime,
			Boolean hasContentImage) {
		this.mTwitterName = twitterName;
		this.mTwitterHandle = twitterHandle;
		this.mProfilePicture = profilePicture;
		this.mTweetContent = tweetContent;
		this.mTweetTime = tweetTime;
		this.mHasContentImage = hasContentImage;
		this.mStatusId = statusId;
		this.mFavoriteCount = favoriteCount;
		this.mReplyTweetId = replyTweetId;
		this.mReplyUserId = replyUserId;
		this.mRetweetCount = retweetCount;
		this.mIsFavorited = isFavorited;
		this.mIsRetweeted = isRetweeted;
	}

	/**
	 * Public constructor class
	 * 
	 * @param statusId
	 * @param favoriteCount
	 * @param replyTweetId
	 * @param replyUserId
	 * @param retweetCount
	 * @param isFavorited
	 * @param isRetweeted
	 * @param twitterName
	 * @param twitterHandle
	 * @param profilePicture
	 * @param tweetContent
	 * @param tweetTime
	 * @param contentImage
	 * @param hasContentImage
	 */
	public FeedRowItem(long statusId, int favoriteCount, long replyTweetId, long replyUserId, int retweetCount, boolean isFavorited,
			boolean isRetweeted, String twitterName, String twitterHandle, Bitmap profilePicture, String tweetContent, String tweetTime,
			Bitmap contentImage, Boolean hasContentImage) {
		this.mTwitterName = twitterName;
		this.mTwitterHandle = twitterHandle;
		this.mProfilePicture = profilePicture;
		this.mTweetContent = tweetContent;
		this.mTweetTime = tweetTime;
		this.mContentImage = contentImage;
		this.mHasContentImage = hasContentImage;
		this.mStatusId = statusId;
		this.mFavoriteCount = favoriteCount;
		this.mReplyTweetId = replyTweetId;
		this.mReplyUserId = replyUserId;
		this.mRetweetCount = retweetCount;
		this.mIsFavorited = isFavorited;
		this.mIsRetweeted = isRetweeted;
	}

	/**
	 * Sets the user's Twitter name
	 * 
	 * @param twitterName
	 */
	public void setTwitterName(String twitterName) {
		this.mTwitterName = twitterName;
	}

	/**
	 * Gets the user's Twitter name
	 * 
	 * @return
	 */
	public String getTwitterName() {
		return this.mTwitterName;
	}

	/**
	 * Sets the user's Twitter handle
	 * 
	 * @param twitterHandle
	 */
	public void setTwitterHandle(String twitterHandle) {
		this.mTwitterHandle = twitterHandle;
	}

	/**
	 * Gets the user's Twitter handle
	 * 
	 * @return
	 */
	public String getTwitterHandle() {
		return "@" + this.mTwitterHandle;
	}

	/**
	 * Sets the user's Twitter profile picture
	 * 
	 * @param profilePic
	 */
	public void setTwitterProfilePicture(Bitmap profilePic) {
		this.mProfilePicture = profilePic;
	}

	/**
	 * Gets the user's Twitter profile picture
	 * 
	 * @return
	 */
	public Bitmap getTwitterProfilePicture() {
		return this.mProfilePicture;
	}

	/**
	 * Sets the content of the Tweet
	 * 
	 * @param tweetContent
	 */
	public void setTweetContent(String tweetContent) {
		this.mTweetContent = tweetContent;
	}

	/**
	 * Gets the content of the Tweet
	 * 
	 * @return
	 */
	public String getTweetContent() {
		return this.mTweetContent;
	}

	/**
	 * Sets the time of the Tweet
	 * 
	 * @param tweetTime
	 */
	public void setTweetTime(String tweetTime) {
		this.mTweetTime = tweetTime;
	}

	/**
	 * Gets the time of the Tweet
	 * 
	 * @return
	 */
	public String getTweetTime() {
		return this.mTweetTime;
	}

	/**
	 * Sets whether the Tweet has an image within it's contents
	 * 
	 * @param hasContentImage
	 */
	public void setHasContentImage(Boolean hasContentImage) {
		this.mHasContentImage = hasContentImage;
	}

	/**
	 * Gets whether the Tweet has an image iwthin it's contents
	 * 
	 * @return
	 */
	public Boolean hasContentImage() {
		return this.mHasContentImage;
	}

	/**
	 * Sets the image within the Tweet
	 * 
	 * @param contentImage
	 */
	public void setContentImage(Bitmap contentImage) {
		this.mContentImage = contentImage;
	}

	/**
	 * Get the image within the Tweet
	 * 
	 * @return
	 */
	public Bitmap getContentImage() {
		return this.mContentImage;
	}

	/**
	 * Sets the Tweet's status ID
	 * 
	 * @param statusId
	 */
	public void setStatusId(long statusId) {
		this.mStatusId = statusId;
	}

	/**
	 * Gets the Tweet's status ID
	 * 
	 * @return
	 */
	public long getStatusId() {
		return this.mStatusId;
	}

	/**
	 * Sets the number of favorites the Tweet has
	 * 
	 * @param favoriteCount
	 */
	public void setFavoriteCount(int favoriteCount) {
		this.mFavoriteCount = favoriteCount;
	}

	/**
	 * Gets the number of favorites the Tweet has
	 * 
	 * @return
	 */
	public int getFavoriteCount() {
		return this.mFavoriteCount;
	}

	/**
	 * Sets whether or not the Tweet is Favorited by the User
	 * 
	 * @param isFavorited
	 */
	public void setIsFavorited(Boolean isFavorited) {
		this.mIsFavorited = isFavorited;
	}

	/**
	 * Gets whether or not the Tweet is Favorited by the User
	 * 
	 * @return
	 */
	public Boolean getIsFavorited() {
		return this.mIsFavorited;
	}

	/**
	 * Sets the Tweet's reply ID
	 * 
	 * @param replyTweetId
	 */
	public void setReplyTweetId(long replyTweetId) {
		this.mReplyTweetId = replyTweetId;
	}

	/**
	 * Gets the Tweet's reply ID
	 * 
	 * @return
	 */
	public long getReplyTweetId() {
		return this.mReplyTweetId;
	}

	/**
	 * Sets the ID of the User being replied to
	 * 
	 * @param replyUserId
	 */
	public void setReplyUserId(long replyUserId) {
		this.mReplyUserId = replyUserId;
	}

	/**
	 * Gets the ID of the User being replied to
	 * 
	 * @return
	 */
	public long getReplyUserId() {
		return this.mReplyUserId;
	}

	/**
	 * Sets the Retweet count for the Tweet
	 * 
	 * @param retweetCount
	 */
	public void setRetweetCount(int retweetCount) {
		this.mRetweetCount = retweetCount;
	}

	/**
	 * Gets the Retweet count for the Tweet
	 * 
	 * @return
	 */
	public int getRetweetCount() {
		return this.mRetweetCount;
	}

	/**
	 * Set whether or not the Tweet is Retweeted by the User
	 * 
	 * @param isRetweeted
	 */
	public void setIsRetweeted(Boolean isRetweeted) {
		this.mIsRetweeted = isRetweeted;
	}

	/**
	 * Gets whether or not the Tweet is Retweeted by the User
	 * 
	 * @return
	 */
	public Boolean getIsRetweeted() {
		return this.mIsRetweeted;
	}
}
