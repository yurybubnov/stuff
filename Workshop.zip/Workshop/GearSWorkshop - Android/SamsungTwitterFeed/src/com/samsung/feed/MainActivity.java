/*
 * Copyright (C) 2014 Samsung Electronics. All Rights Reserved.
 * Source code is licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and limitations under the License.
 *
 * IMPORTANT LICENSE NOTE:
 * The IMAGES AND RESOURCES are licensed under the Creative Commons BY-NC-SA 3.0
 * License (http://creativecommons.org/licenses/by-nc-sa/3.0/).
 * The source code is allows commercial re-use, but IMAGES and RESOURCES forbids it.
 */

package com.samsung.feed;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.FragmentManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.User;
import twitter4j.auth.AccessToken;
import twitter4j.auth.RequestToken;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.Calendar;

/**
 * Creates the custom action bar layout, including the count down logic. Creates
 * the FeedFragment. Allows the user to authorize the application access to
 * their Twitter account using TokenGet and AccessTokenGet async tasks.
 * 
 * @author k.schaller
 *
 */
public class MainActivity extends Activity {
	/** obtained from apps.twitter.com -- Should be kept private */
	private static final String CONSUMER_KEY = "0VoA7la9rDBLlZklhNmnFu2gD";
	private static final String CONSUMER_SECRET = "uBPs3TvGCJVMhIWQptQbfW8aNQbLMYHT7nQlnSM5xaDFBvwc4B";
	/** Used to store secrets & keep them private to this activity */
	public SharedPreferences pref;

	/** Twitter object from twitter4j libraries */
	public static Twitter sTwitter;
	/** Used to make OAuth request for access */
	public RequestToken requestToken = null;
	private String mOauth_verifier;
	Dialog mAuth_dialog;
	ProgressDialog mProgress;
	static RelativeLayout sTwitterIcon;
	ImageView mProfileIcon;
	Boolean mClicked = false;
	public static Context sContext;
	public static RelativeLayout sNotificationContainer;

	/**
	 * Create and apply a custom action bar. Check to see if the OAuth
	 * tokens/secrets are available. If so, create a new instance of the Twitter
	 * object and add a new FeedFragment to the container; if not, set a click
	 * listener on the icon to allow the user to log in.
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		sContext = this;

		/** Create the custom action bar */
		createCustomActionBar();

		/** Check for data connection */
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
		boolean isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();

		/**
		 * Get shared preferences and store the CONSUMER_KEY and
		 * CONSUMER_SECRET
		 */
		pref = getPreferences(0);
		SharedPreferences.Editor edit = pref.edit();
		edit.putString("CONSUMER_KEY", CONSUMER_KEY);
		edit.putString("CONSUMER_SECRET", CONSUMER_SECRET);
		edit.commit();

		FragmentManager fm = getFragmentManager();
		FeedFragment feedFragment = (FeedFragment) fm.findFragmentByTag("TAG_FEED_FRAG");

		/**
		 * Create a new instance of the Twitter object and set it's
		 * CONSUMER_KEY and CONSUMER_SECRET
		 */
		sTwitter = new TwitterFactory().getInstance();
		sTwitter.setOAuthConsumer(pref.getString("CONSUMER_KEY", ""),pref.getString("CONSUMER_SECRET", ""));

		if(isConnected) {
			/** If it is connected then continue normally */

			/**
			 * Check for key ACCESS_TOKEN or ACCESS_TOKEN_SECRET in
			 * SharedPreferences
			 */
			if (!pref.getString("ACESS_TOKEN", "").isEmpty()|| !pref.getString("ACCESS_TOKEN_SECRET", "").isEmpty()) {
				/** Found: create a new AccessToken with the values */
				AccessToken token = new AccessToken(pref.getString("ACCESS_TOKEN", ""), 
						pref.getString("ACCESS_TOKEN_SECRET", ""));
				/** Set the OAuth Access Token for authorization header */
				sTwitter.setOAuthAccessToken(token);

				/** Add a new FeedFragment if one doesn't exist already */
				if (feedFragment == null) {
					feedFragment = new FeedFragment();
					getFragmentManager().beginTransaction().replace(R.id.container, feedFragment, "TAG_FEED_FRAG").commit();
				}

				/** Set the icon to the user's profile image */
				new getProfileImage().execute();
			} else {
				Bundle bundle = new Bundle();
				bundle.putString("STATUS", "logged_in");
				feedFragment = new FeedFragment();
				feedFragment.setArguments(bundle);
				getFragmentManager().beginTransaction().replace(R.id.container,feedFragment).commit();
				sTwitterIcon.setOnClickListener(new Login());
			}
		} else {
			Bundle bundle = new Bundle();
			bundle.putString("STATUS", "no_connection");
			feedFragment = new FeedFragment();
			feedFragment.setArguments(bundle);
			getFragmentManager().beginTransaction().replace(R.id.container,feedFragment).commit();
			Toast.makeText(this, "No Network Connection. Please restart app when you have connection again.", Toast.LENGTH_LONG).show();
		}
	}

	/**
	 * Cleans up the stored cookies.
	 */
	@Override
	public void onDestroy() {
		super.onDestroy();
		CookieSyncManager.createInstance(this);
		CookieManager cookieManager = CookieManager.getInstance();
		cookieManager.removeSessionCookie();
	}

	/**
	 * Handle configuration changes as defined in the AndroidManifest.xml so
	 * that the ActionBar is redrawn upon orientation change and the profile
	 * image is reloaded. This is done so that the FeedFragment isn't redrawn
	 * when MainActivity is recreated.
	 */
	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		createCustomActionBar();
		new getProfileImage().execute();
	}

	/**
	 * Inflates one of two custom views that overlays the ActionBar depending on
	 * the orientation of the device, and populates the count down clock with
	 * the appropriate data.
	 * 
	 * @SuppressLint("InflateParams") : Used when inflating the custom view for the ActionBar because there's no parent view.
	 */
	@SuppressLint("InflateParams")
	private void createCustomActionBar() {
		/** Hide the ActionBar's 'Home' arrow and icon. */
		getActionBar().setDisplayShowHomeEnabled(false);
		/** Hide the ActionBar's title. */
		getActionBar().setDisplayShowTitleEnabled(false);
		LayoutInflater inflater = LayoutInflater.from(this);

		/**
		 * Check to see if the orientation of the device is in portrait or
		 * undefined (this is the default layout to be used)
		 */
		if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT
				|| getResources().getConfiguration().orientation == Configuration.ORIENTATION_UNDEFINED) {
			/** Inflate the View */
			View customActionBar = inflater.inflate(R.layout.custom_action_bar,
					null);
			ImageView icon = (ImageView) customActionBar.findViewById(R.id.action_bar_icon);
			TextView title = (TextView) customActionBar.findViewById(R.id.action_bar_title);
			TextView days = (TextView) customActionBar.findViewById(R.id.days_text);
			TextView hours = (TextView) customActionBar.findViewById(R.id.hours_text);
			TextView minutes = (TextView) customActionBar.findViewById(R.id.minutes_text);
			sTwitterIcon = (RelativeLayout) customActionBar.findViewById(R.id.twitter_icon_container);
			mProfileIcon = (ImageView) customActionBar.findViewById(R.id.profile_image);
			sNotificationContainer = (RelativeLayout) customActionBar.findViewById(R.id.notification_icon_container);

			/**
			 * Call method to calculate the time remaining and populate the View
			 * fields
			 */
			setCountdownClock(days, hours, minutes);

			/** Set the ActionBar's custom view to the view inflated above */
			getActionBar().setCustomView(customActionBar);
			/** Set the boolean to allow custom view to be shown over ActionBar */
			getActionBar().setDisplayShowCustomEnabled(true);

			/**
			 * Check to see if the current date is Nov. 11, 12, or 13th. If so,
			 * call setConferenceActionBar() to change the view to display
			 * current day of SDC
			 */
			if ((Calendar.getInstance().get(Calendar.MONTH) == Calendar.NOVEMBER
					&& Calendar.getInstance().get(Calendar.DAY_OF_MONTH) >= 11) 
					&& (Calendar.getInstance().get(Calendar.MONTH) == Calendar.NOVEMBER 
					&& Calendar.getInstance().get(Calendar.DAY_OF_MONTH) <= 14)) {
				LinearLayout countDownContainer = (LinearLayout) customActionBar.findViewById(R.id.action_bar_countdown_container);
				RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(113, RelativeLayout.LayoutParams.WRAP_CONTENT);
				params.leftMargin = 13;
				params.addRule(RelativeLayout.ALIGN_PARENT_START);
				icon.setLayoutParams(params);
				countDownContainer.setVisibility(View.GONE);
				title.setVisibility(View.VISIBLE);
				setConferenceActionBar(icon, title);
			}
		} else {
			/** Device orientation is landscape; inflate a different view */
			View customActionBar = inflater.inflate(R.layout.custom_action_bar_horizontal, null);
			ImageView icon = (ImageView) customActionBar.findViewById(R.id.action_bar_icon);
			TextView title = (TextView) customActionBar.findViewById(R.id.action_bar_title);
			TextView days = (TextView) customActionBar.findViewById(R.id.days_text);
			TextView hours = (TextView) customActionBar.findViewById(R.id.hours_text);
			TextView minutes = (TextView) customActionBar.findViewById(R.id.minutes_text);
			sTwitterIcon = (RelativeLayout) customActionBar.findViewById(R.id.twitter_icon_container);
			mProfileIcon = (ImageView) customActionBar.findViewById(R.id.profile_image);
			sNotificationContainer = (RelativeLayout) customActionBar.findViewById(R.id.notification_icon_container);

			/**
			 * Call method to calculate the time remaining and populate the View
			 * fields
			 */
			setCountdownClock(days, hours, minutes);

			/** Set the ActionBar's custom view to the view inflated above */
			getActionBar().setCustomView(customActionBar);
			/** Set the boolean to allow custom view to be shown over ActionBar */
			getActionBar().setDisplayShowCustomEnabled(true);

			/**
			 * Check to see if the current date is Nov. 11, 12, or 13th. If so,
			 * call setConferenceActionBar() to change the view to display
			 * current day of SDC
			 */
			if ((Calendar.getInstance().get(Calendar.MONTH) == Calendar.NOVEMBER 
					&& Calendar.getInstance().get(Calendar.DAY_OF_MONTH) >= 11)
					&& (Calendar.getInstance().get(Calendar.MONTH) == Calendar.NOVEMBER 
					&& Calendar.getInstance().get(Calendar.DAY_OF_MONTH) <= 14)) {
				LinearLayout countDownContainer = (LinearLayout) customActionBar.findViewById(R.id.action_bar_countdown_container);
				RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(113, RelativeLayout.LayoutParams.WRAP_CONTENT);
				params.leftMargin = 13;
				params.addRule(RelativeLayout.ALIGN_PARENT_START);
				icon.setLayoutParams(params);
				countDownContainer.setVisibility(View.GONE);
				title.setVisibility(View.VISIBLE);
				setConferenceActionBar(icon, title);
			}
		}
	}

	/**
	 * Calculates the number of days, hours, and minutes left until SDC 2014
	 * begins.
	 * 
	 * @param days
	 * @param hours
	 * @param minutes
	 */
	private void setCountdownClock(TextView days, TextView hours, TextView minutes) {
		/** 314 is the day of the year that November 11th falls on */
		double daysNum = (316 - Calendar.getInstance().get(Calendar.DAY_OF_YEAR));
		/** 8 is the hour the conference starts */
		double hoursNum = (8 - Calendar.getInstance().get(Calendar.HOUR_OF_DAY));
		/** 00 is the number of minutes into the hour the conference starts */
		double minutesNum = (00 - Calendar.getInstance().get(Calendar.MINUTE));

		/** Calculate the total time into number of minutes until the conference */
		int totalMinute = ((314 * 24) * 60) + (8 * 60);

		/** Calculate the current in into number of minutes */
		int nowTime = ((Calendar.getInstance().get(Calendar.DAY_OF_YEAR) * 24) * 60)
				+ (Calendar.getInstance().get(Calendar.HOUR_OF_DAY) * 60)
				+ (Calendar.getInstance().get(Calendar.MINUTE));

		/** Get the difference between the time until and the current time */
		int differenceMin = (totalMinute - nowTime);

		/**
		 * Calculate the days, hours, and minutes by dividing into the remainder
		 * of the previous division
		 */
		daysNum = (double) ((differenceMin / 60.0000) / 24.0000);
		hoursNum = (double) ((daysNum % 1.0000) * 24.0000);
		minutesNum = (double) ((hoursNum % 1.0000) * 60.0000);

		/** Format the time */
		DecimalFormat format = new DecimalFormat("##");

		days.setText(format.format(daysNum));
		hours.setText(format.format(hoursNum));
		minutes.setText(format.format(minutesNum));
	}

	/**
	 * Changes the layout of the action bar to display a different icon and
	 * title depending on what day of the conference it is.
	 * 
	 * @param icon
	 * @param title
	 */
	private void setConferenceActionBar(ImageView icon, TextView title) {		
		/**
		 * Checks the current day to determine what icon and title to use. If
		 * it's past the date, then display a difference logo and title.
		 */
		if (Calendar.getInstance().get(Calendar.DAY_OF_MONTH) == 11) {
			title.setText("Day 1");
			icon.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.day1));
		} else if (Calendar.getInstance().get(Calendar.DAY_OF_MONTH) == 12) {
			title.setText("Day 2");
			icon.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.day2));
		} else if (Calendar.getInstance().get(Calendar.DAY_OF_MONTH) == 13) {
			title.setText("Day 3");
			icon.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.day3));
		} else if ((Calendar.getInstance().get(Calendar.MONTH) >= 11 
				&& Calendar.getInstance().get(Calendar.DAY_OF_MONTH) >= 14)
				|| Calendar.getInstance().get(Calendar.MONTH) > 11
				|| Calendar.getInstance().get(Calendar.YEAR) > 2014) {
			icon.setImageBitmap(BitmapFactory.decodeResource(getResources(),R.drawable.sdc_trans));
			title.setText("Join us next year!");
		}
	}
	
	/**
	 * Creates a click listener that calls the TokenGet() async task.
	 */
	public class Login implements OnClickListener {
		@Override
		public void onClick(View v) {
			if (!mClicked) {
				/** Check for data connection */
				ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
				NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
				boolean isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();

				if(isConnected) {
					mClicked = true;
					new TokenGet().execute();
				} else {
					Toast.makeText(MainActivity.sContext, "No Network Connection. Press the Twitter icon when you have connection.", Toast.LENGTH_LONG).show();
				}
			}
		}
	}

	/**
	 * Sends a request to Twitter asking for a RequestToken to generate a URL,
	 * so the user can authorize access to the application.
	 */
	private class TokenGet extends AsyncTask<String, String, String> {
		String mOauth_url;

		/**
		 * Create and display a ProgressDialog.
		 */
		@Override
		protected void onPreExecute() {
			mProgress = new ProgressDialog(MainActivity.this);
			mProgress.setMessage("Loading Website...");
			mProgress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			mProgress.setIndeterminate(true);
			mProgress.setCanceledOnTouchOutside(false);
			mProgress.show();
		}

		/**
		 * Attempt to make the call to Twitter to get the Request Token. Store
		 * the OAuth Request Token and authentication URL that needs to be
		 * returned to the user.
		 */
		@Override
		protected String doInBackground(String... args) {
			try {
				requestToken = sTwitter.getOAuthRequestToken();
				mOauth_url = requestToken.getAuthenticationURL();
				Log.d("tag", mOauth_url);
			} catch (TwitterException e) {
				e.printStackTrace();
			}

			return mOauth_url;
		}

		/**
		 * Receive the authentication URL and display it within a newly created
		 * WebView. Once the WebView has received a response check it for the
		 * key "oauth_verifier" and store the response URL.
		 */
		@Override
		protected void onPostExecute(String oauth_url) {
			WebView mWeb;
			mProgress.dismiss();

			/** Check to make sure that the Request Token URL has been generated */
			if (oauth_url != null) {
				/** Create a new dialog */
				mAuth_dialog = new Dialog(MainActivity.this);
				mAuth_dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
				mAuth_dialog.setContentView(R.layout.auth_webview);
				mAuth_dialog.setCanceledOnTouchOutside(false);
				mAuth_dialog.setOnCancelListener(new OnCancelListener() {

					@Override
					public void onCancel(DialogInterface dialog) {
						mClicked = false;
						sTwitter.setOAuthAccessToken(null);
					}
				});
				mWeb = (WebView) mAuth_dialog.findViewById(R.id.web_view);
				/** Load the Request Token URL */
				mWeb.loadUrl(oauth_url);
				mWeb.setWebViewClient(new WebViewClient() {
					boolean authComplete = false;

					@Override
					public void onPageStarted(WebView view, String url, Bitmap favicon) {
						super.onPageStarted(view, url, favicon);
					}

					/**
					 * Check for key "oauth_verifier" when page request has
					 * finished. If it contains it, dismiss the dialog, then
					 * store the URL and then call AccessTokenGet(); otherwise,
					 * dismiss the dialog, then display an error message.
					 */
					@Override
					public void onPageFinished(WebView view, String url) {
						super.onPageFinished(view, url);
						Log.d("tag", "onPageFinished");
						if (url.contains("oauth_verifier") && authComplete == false) {
							Log.d("tag", "if one");
							authComplete = true;
							Uri uri = Uri.parse(url);
							mOauth_verifier = uri.getQueryParameter("oauth_verifier");
							mAuth_dialog.dismiss();
							new AccessTokenGet().execute();
						} else if (url.contains("denied")) {
							mAuth_dialog.dismiss();
							Toast.makeText(MainActivity.this, "Permission Denied", Toast.LENGTH_SHORT).show();
						}
					}
				});
				mAuth_dialog.show();
				mAuth_dialog.setCancelable(true);
			} else {
				/** Most likely due to credentials not being requested */
				Toast.makeText(MainActivity.this, "Network Error or Invalid Credentials", Toast.LENGTH_SHORT).show();
				mClicked = false;						
			}
		}
	}

	/**
	 * From the requestToken and mOauth_verifier request the OAuth Access Token
	 * .Stores the ACCESS_TOKEN and ACCESS_TOKEN_SECRET in the
	 * SharedPreferences, download the user's photo and set the IamgeView to it,
	 * and create and add a new FeedFragment.
	 */
	private class AccessTokenGet extends AsyncTask<String, String, Boolean> {
		/** Token generated after user authorized application */
		AccessToken mAccessToken;
		Bitmap bm;

		/**
		 * Create and display a new ProgressDialog
		 */
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			mProgress = new ProgressDialog(MainActivity.this);
			mProgress.setMessage("Fetching Data...");
			mProgress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			mProgress.setIndeterminate(true);
			mProgress.setCanceledOnTouchOutside(false);
			mProgress.show();
		}

		/**
		 * Try to request the OAuthAccessToken. If successful, store the
		 * ACCESS_TOKEN and ACCESS_TOKEN_SECRET keys, and the user's profile
		 * image URL into the SharedPreferences. Try to download the user's
		 * profile image.
		 */
		@Override
		protected Boolean doInBackground(String... args) {
			try {
				mAccessToken = sTwitter.getOAuthAccessToken(requestToken, mOauth_verifier);
				SharedPreferences.Editor edit = pref.edit();
				edit.putString("ACCESS_TOKEN", mAccessToken.getToken());
				edit.putString("ACCESS_TOKEN_SECRET", mAccessToken.getTokenSecret());

				User user = sTwitter.showUser(mAccessToken.getUserId());
				edit.putString("IMAGE_URL", user.getOriginalProfileImageURL());
				edit.commit();
			} catch (TwitterException e) {
				e.printStackTrace();
			}

			try {
				bm = BitmapFactory.decodeStream((InputStream) new URL(pref.getString("IMAGE_URL", "")).getContent());
			} catch (IOException e) {
				e.printStackTrace();
			}
			return true;
		}

		/**
		 * Dismiss the ProgressDialog and set the ImageView to the downloaded
		 * bitmap.
		 */
		@Override
		protected void onPostExecute(Boolean response) {
			if (response) {
				mProgress.dismiss();
				mProfileIcon.setVisibility(View.VISIBLE);
				if (bm != null)
					mProfileIcon.setImageBitmap(bm);
				else
					mProfileIcon.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.sdc_logo));
				getFragmentManager().beginTransaction().replace(R.id.container, new FeedFragment()).commit();
			}
		}
	}

	/**
	 * Download the user's profile image and set the ImageView to the returned
	 * Bitmap.
	 */
	private class getProfileImage extends AsyncTask<String, String, Boolean> {
		Bitmap bm;

		/**
		 * Attempt to download the user's bitmap.
		 */
		@Override
		protected Boolean doInBackground(String... params) {
			try {
				bm = BitmapFactory.decodeStream((InputStream) new URL(pref.getString("IMAGE_URL", "")).getContent());
			} catch (IOException e) {
				e.printStackTrace();
			}
			return true;
		}

		/** Set the ImageView to the downloaded Bitmap */
		@Override
		protected void onPostExecute(Boolean response) {
			mProfileIcon.setVisibility(View.VISIBLE);
			if (bm != null)
				mProfileIcon.setImageBitmap(bm);
			else
				mProfileIcon.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.sdc_logo));
		}
	}
}
