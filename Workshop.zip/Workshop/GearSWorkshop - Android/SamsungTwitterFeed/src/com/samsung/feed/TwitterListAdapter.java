/*
 * Copyright (C) 2014 Samsung Electronics. All Rights Reserved.
 * Source code is licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and limitations under the License.
 *
 * IMPORTANT LICENSE NOTE:
 * The IMAGES AND RESOURCES are licensed under the Creative Commons BY-NC-SA 3.0
 * License (http://creativecommons.org/licenses/by-nc-sa/3.0/).
 * The source code is allows commercial re-use, but IMAGES and RESOURCES forbids it.
 */

package com.samsung.feed;

import android.app.Dialog;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import twitter4j.StatusUpdate;
import twitter4j.Twitter;
import twitter4j.TwitterException;

import java.util.ArrayList;

/**
 * ArrayAdapter for each FeedRowItem within the FeedFragment's ListView
 * 
 * @author k.schaller
 *
 */
public class TwitterListAdapter extends ArrayAdapter<FeedRowItem> {
	private final Context CONTEXT;
	private final ArrayList<FeedRowItem> ITEMS_ARRAY_LIST;

	/** Twitter4j variable */
	private Twitter mTwitter;

	Dialog mDialog;
	EditText mTweetText;

	/** Constructor class */
	public TwitterListAdapter(Context context,
			ArrayList<FeedRowItem> itemsArrayList) {
		super(context, R.layout.row_layout, itemsArrayList);

		this.CONTEXT = context;
		this.ITEMS_ARRAY_LIST = itemsArrayList;
	}

	/**
	 * Inflates the view for the FeedRowItem, set's the Views and text, and sets
	 * the click listeners.
	 */
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		LayoutInflater inflater = (LayoutInflater) CONTEXT
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

		View rowView = inflater.inflate(R.layout.row_layout, parent, false);

		ImageView imageContent = (ImageView) rowView.findViewById(R.id.twitter_image_content);
		ImageView retweetImage = (ImageView) rowView.findViewById(R.id.tweet_retweet);
		ImageView userImage = (ImageView) rowView.findViewById(R.id.twitter_picture);

		TextView twitterName = (TextView) rowView.findViewById(R.id.twitter_name);
		TextView twitterHandle = (TextView) rowView.findViewById(R.id.twitter_handle);
		TextView tweetContent = (TextView) rowView.findViewById(R.id.twitter_content);
		TextView minSince = (TextView) rowView.findViewById(R.id.tweet_time);
		RelativeLayout favorite = (RelativeLayout) rowView.findViewById(R.id.tweet_favorite_container);
		ImageView mFavoriteImage = (ImageView) rowView.findViewById(R.id.tweet_favorite);
		TextView favoriteCount = (TextView) rowView.findViewById(R.id.tweet_favorite_count);
		RelativeLayout reply = (RelativeLayout) rowView.findViewById(R.id.tweet_reply_container);
		RelativeLayout retweet = (RelativeLayout) rowView.findViewById(R.id.tweet_retweet_container);
		TextView retweetCount = (TextView) rowView.findViewById(R.id.tweet_retweet_count);

		twitterName.setText(ITEMS_ARRAY_LIST.get(position).getTwitterName());
		twitterHandle.setText(ITEMS_ARRAY_LIST.get(position).getTwitterHandle());
		tweetContent.setText(ITEMS_ARRAY_LIST.get(position).getTweetContent());
		userImage.setImageBitmap(ITEMS_ARRAY_LIST.get(position).getTwitterProfilePicture());
		minSince.setText(ITEMS_ARRAY_LIST.get(position).getTweetTime());

		/** Used to check Tweet for an image and set it; otherwise hide the view */
		if (ITEMS_ARRAY_LIST.get(position).hasContentImage())
			imageContent.setImageBitmap(ITEMS_ARRAY_LIST.get(position).getContentImage());
		else
			imageContent.setVisibility(View.GONE);

		/** Used to check Tweet for an favorite count and set the view */
		if (ITEMS_ARRAY_LIST.get(position).getFavoriteCount() > 0)
			favoriteCount.setText(Integer.toString(ITEMS_ARRAY_LIST.get(position).getFavoriteCount()));

		/** Used to check Tweet for an retweet count and set the view */
		if (ITEMS_ARRAY_LIST.get(position).getRetweetCount() > 0)
			retweetCount.setText(Integer.toString(ITEMS_ARRAY_LIST.get(position).getRetweetCount()));

		/** Used to check Tweet if current user favorited tweet and set icon */
		if (ITEMS_ARRAY_LIST.get(position).getIsFavorited()) {
			mFavoriteImage.setImageBitmap(BitmapFactory.decodeResource(getContext().getResources(), R.drawable.favorite_on));
		}
		/** Used to check Tweet if current user retweeted tweet and set icon */
		if (ITEMS_ARRAY_LIST.get(position).getIsRetweeted()) {
			retweetImage.setImageBitmap(BitmapFactory.decodeResource(getContext().getResources(), R.drawable.retweet_on));
		}

		favorite.setOnClickListener(new Favorite(ITEMS_ARRAY_LIST.get(position)));
		reply.setOnClickListener(new Reply(ITEMS_ARRAY_LIST.get(position)));
		retweet.setOnClickListener(new Retweet(ITEMS_ARRAY_LIST.get(position)));

		return rowView;
	}

	/**
	 * Executes the FavoriteTweet() method when a click listener is triggered.
	 * 
	 * @author k.schaller
	 *
	 */
	public class Favorite implements OnClickListener {
		FeedRowItem tweet;

		/**
		 * Public constructor class.
		 * 
		 * @param feedRowItem
		 */
		public Favorite(FeedRowItem feedRowItem) {
			tweet = feedRowItem;
		}

		/**
		 * Executes FavoriteTweet() when a View, v, is clicked.
		 */
		@Override
		public void onClick(View v) {
			new FavoriteTweet().execute(tweet);
		}

	}

	/**
	 * Displays a Dialog, sets values for different view, and allows a user to
	 * input text and sets up a click listener to execute ReplyTweet().
	 * 
	 * @author k.schaller
	 *
	 */
	public class Reply implements OnClickListener {
		FeedRowItem tweet;

		/**
		 * Public constructor class.
		 * 
		 * @param feedRowItem
		 */
		public Reply(FeedRowItem feedRowItem) {
			tweet = feedRowItem;
		}

		/**
		 * Creates a Dialog, sets Views, and creates/sets a click listener for a
		 * view that, when triggered, executes ReplyTweet().
		 */
		@Override
		public void onClick(View v) {
			/** Create and show a new dialog */
			mDialog = new Dialog(MainActivity.sContext);
			mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
			mDialog.setContentView(R.layout.tweet_dialog);
			mTweetText = (EditText) mDialog.findViewById(R.id.tweet_text_field);
			mTweetText.setText(tweet.getTwitterHandle() + " ");
			TextView reply_text = (TextView) mDialog.findViewById(R.id.tweet_reply);
			reply_text.setText(tweet.getTweetContent());
			reply_text.setVisibility(View.VISIBLE);
			ImageView post_tweet = (ImageView) mDialog.findViewById(R.id.post_tweet);
			post_tweet.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					new ReplyTweet().execute(tweet);
				}
			});
			mDialog.show();
		}

	}

	/**
	 * Executes the RetweetTweet() method when a click listener is triggered.
	 * 
	 * @author k.schaller
	 *
	 */
	public class Retweet implements OnClickListener {
		FeedRowItem tweet;

		/**
		 * Public constructor class.
		 * 
		 * @param feedRowItem
		 */
		public Retweet(FeedRowItem feedRowItem) {
			tweet = feedRowItem;
		}

		/**
		 * Executes RetweetTweet() when a View, v, is clicked.
		 */
		@Override
		public void onClick(View v) {
			new RetweetTweet().execute(tweet);
		}

	}

	/**
	 * Favorites a tweet using the Twitter4j library method createFavorite(),
	 * sets the FeedRowItem setIsFavorited to true, and notifies the data set
	 * that it has been changed.
	 * 
	 * @author k.schaller
	 *
	 */
	private class FavoriteTweet extends AsyncTask<FeedRowItem, String, Boolean> {
		FeedRowItem update;

		/**
		 * Attempts to favorite a tweet and returns a boolean.
		 */
		@Override
		protected Boolean doInBackground(FeedRowItem... params) {
			mTwitter = MainActivity.sTwitter;
			try {
				mTwitter.createFavorite(params[0].getStatusId());
				update = params[0];
				return true;
			} catch (TwitterException e) {
				e.printStackTrace();
				return false;
			}
		}

		/**
		 * Sets the setIsFavorited value to true if the tweet was favorited and
		 * notifies the data set that it has been changed.
		 */
		@Override
		protected void onPostExecute(Boolean response) {
			if (response != false) {
				update.setIsFavorited(true);
				notifyDataSetChanged();
			}
		}
	}

	/**
	 * Replies to a tweet using the Twitter4j library method
	 * inReplyToStatusId(), and displays a message upon success.
	 * 
	 * @author k.schaller
	 *
	 */
	private class ReplyTweet extends AsyncTask<FeedRowItem, String, Boolean> {

		/**
		 * Remove the dialog that contained the user's response.
		 */
		@Override
		protected void onPreExecute() {
			mDialog.dismiss();
		}

		/**
		 * Create a new StatusUpdate with the user's response text, set the
		 * tweet ID that it is replying to, attempt to update the status, and
		 * return a boolean value.
		 */
		@Override
		protected Boolean doInBackground(FeedRowItem... params) {
			mTwitter = MainActivity.sTwitter;
			StatusUpdate statusUpdate = new StatusUpdate(mTweetText.getText().toString());
			statusUpdate.inReplyToStatusId(params[0].getStatusId());
			try {
				mTwitter.updateStatus(statusUpdate);
				return true;
			} catch (TwitterException e) {
				e.printStackTrace();
				return false;
			}
		}

		/**
		 * Display a success message if the response was posted.
		 */
		@Override
		protected void onPostExecute(Boolean response) {
			if (response != false)
				Toast.makeText(MainActivity.sContext, "Successfully Replied", Toast.LENGTH_SHORT).show();
		}
	}

	/**
	 * Retweets a tweet using the Twitter4j library method retweetStatus(), sets
	 * the FeedRowItem setIsRetweeted to true, and notifies the data set that it
	 * has been changed.
	 * 
	 * @author k.schaller
	 *
	 */
	private class RetweetTweet extends AsyncTask<FeedRowItem, String, Boolean> {
		FeedRowItem retweet;

		/**
		 * Attempts to retweet a tweet and returns a boolean.
		 */
		@Override
		protected Boolean doInBackground(FeedRowItem... params) {
			mTwitter = MainActivity.sTwitter;
			retweet = params[0];

			try {
				mTwitter.retweetStatus(params[0].getStatusId());
				return true;
			} catch (TwitterException e) {
				e.printStackTrace();
				return false;
			}
		}

		/**
		 * Sets the setIsRetweeted value to true if the tweet was retweeted and
		 * notifies the data set that it has been changed.
		 */
		@Override
		protected void onPostExecute(Boolean response) {
			if (response != false) {
				retweet.setIsRetweeted(true);
				notifyDataSetChanged();
			}
		}
	}
}
