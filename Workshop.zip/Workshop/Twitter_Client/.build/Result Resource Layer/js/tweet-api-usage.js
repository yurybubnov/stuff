(function (TwitterClient) {

	var TC;
	
	var TC;
    var accessToken = localStorage.getItem("ACCESS_TOKEN");
    var accessTokenSecret = localStorage.getItem("ACCESS_TOKEN_SECRET");
    var processing = document.getElementById("ui-processing");
	processing.style.display='none';

    if(accessToken && accessTokenSecret) {
    	TC = new TwitterClient({
    			consumer_key: "0VoA7la9rDBLlZklhNmnFu2gD",
				consumer_secret: "uBPs3TvGCJVMhIWQptQbfW8aNQbLMYHT7nQlnSM5xaDFBvwc4B",
				access_token: accessToken,
				access_token_secret: accessTokenSecret
    	});
    }
	
	function success() {
		processing.style.display='none';
		alert("Tweet Sent!");
		window.history.back();
	}

	function bindButtons() {
		var buttons = {
				postTweet: document.getElementById("post-tweet"),
		},
		inputs = {
				tweetContent: document.getElementById("tweet-content"),
		};
		
		buttons.postTweet.addEventListener("click", function () {
			if (!TC) {
				alert("Please add your keys first");
				return;
			}
			
			processing.style.display='block';
			TC.tweet(inputs.tweetContent.value, success);
		});
		/**
		buttons.getTweetsWall.addEventListener("click", function () {
			if (!TC) {
				alert("Please add your keys first");
				return;
			}

			TC.myWall(showTweets);
		});
		*/
	}

	document.addEventListener("DOMContentLoaded", bindButtons);
}(window.TwitterClient));

window.onload = function () {
    // add eventListener for tizenhwkey
    document.addEventListener('tizenhwkey', function(e) {
        if(e.keyName == "back")
			window.history.back();
    });
};