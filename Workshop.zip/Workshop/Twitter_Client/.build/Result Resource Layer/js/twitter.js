(function () {
	"use strict";

	var HASHTAG = "#Samsung";

	/**
	 * @param keys
	 * @param keys.consumer_key
	 * @param keys.consumer_secret
	 * @param keys.access_token
	 * @param keys.access_token_secret
	 * @returns {TwitterClient}
	 * @constructor
	 */

	var TwitterClient = function (keys) {
		if (!(this instanceof TwitterClient)) {
			return new TwitterClient(keys);
		}

		if (!keys) {
			throw new Error("Please provide all access keys as argument for TwitterClient constructor");
		}

		if(keys.access_token && keys.access_token_secret) {
			this.__secret = {
					CONSUMER_KEY: keys.consumer_key,
					CONSUMER_SECRET: keys.consumer_secret,
					ACCESS_TOKEN: keys.access_token,
					ACCESS_TOKEN_SECRET: keys.access_token_secret
			};
		} else {
			this.__secret = {
					CONSUMER_KEY: keys.consumer_key,
					CONSUMER_SECRET: keys.consumer_secret
			};
		}
	};

	function createNonce() {
		return btoa("SDC2014" + Math.random() + Date.now()).replace(/[\/+=]/g, "").substr(0, 32);
	}

	function pushFromQueryString(parameters, part) {
		var split = part.split("=");
		parameters.push({
			key: encodeURIComponent(split[0]),
			value: split[1]
		});
	}

	function createSignature(instance, authHeaders, method, url, queryString, postData) {
		var parameters = [],
		parametersString,
		secrets = instance.__secret,
		signingKey,
		rawSignature,
		queryArray = queryString && queryString.split("&") || [],
		dataArray = postData && postData.split("&") || [],
		pushParameterHelper = pushFromQueryString.bind(null, parameters),
		authHeadersKeys = Object.keys(authHeaders);

		// Collect parameters
		authHeadersKeys.forEach(function (headerKey) {
			parameters.push({
				key: encodeURIComponent(headerKey),
				value: encodeURIComponent(authHeaders[headerKey])
			});
		});

		queryArray.forEach(pushParameterHelper);
		dataArray.forEach(pushParameterHelper);

		parameters.sort(function (a, b) {
			if(a.key === b.key) return 0;
			return a.key > b.key ? 1 : -1;
		});

		parametersString = method + "&" + encodeURIComponent(url);

		parametersString += "&" + encodeURIComponent(parameters.map(function (param) {
			return param.key + "=" + param.value;
		}).join("&"));

		signingKey = encodeURIComponent(secrets.CONSUMER_SECRET) + "&";

		if (secrets.ACCESS_TOKEN_SECRET) {
			signingKey += encodeURIComponent(secrets.ACCESS_TOKEN_SECRET);
		}

		rawSignature = CryptoJS.HmacSHA1(parametersString, signingKey);

		return CryptoJS.enc.Base64.stringify(rawSignature);
	}

	function joinHeader(authHeaders, headerName) {
		return headerName + "=\"" + encodeURIComponent(authHeaders[headerName]) + "\"";
	}

	function makeRequest(instance, method, url, query, data, callback, signature) {
		var authString = "OAuth ",
		requestURL = url,
		request = new XMLHttpRequest(),
		authHeaders = {
			oauth_consumer_key: instance.__secret.CONSUMER_KEY,
			oauth_nonce: createNonce(),
			//oauth_signature
			oauth_signature_method: "HMAC-SHA1",
			oauth_timestamp: Math.round(Date.now() / 1000),
			oauth_token: instance.__secret.ACCESS_TOKEN,
			oauth_version: "1.0"
		};

		authHeaders["oauth_signature"] = createSignature(instance, authHeaders, method, url, query);

		if (query) {
			requestURL += "?" + query;
		}		
		
		authString += Object.keys(authHeaders).map(joinHeader.bind(null, authHeaders)).join(", ");

		request.open(method, requestURL);

		request.setRequestHeader("Content-Type", "application/json");
		request.setRequestHeader("Authorization", authString);
		request.responseType = "json";

		request.onreadystatechange = function () {
			if (request.status === 200 && request.readyState === 4) {
				if (typeof callback === "function"){
					callback(request.response);
				}
			} else if(request.status !== 200 && request.readyState === 4) {
				alert("Failed");
			}
		};

		request.send(data);
	}
	
	function requestToken(instance, method, url, query, data, callback, callbackfunction) {
		var authString = "OAuth ",
		requestURL = url,
		request = new XMLHttpRequest(),
		authHeaders = {
			oauth_consumer_key: instance.__secret.CONSUMER_KEY,
			oauth_nonce: createNonce(),
			// oauth_signature
			oauth_signature_method: "HMAC-SHA1",
			oauth_timestamp: Math.round(Date.now() / 1000),
			oauth_version: "1.0"
		};

		if(callback) {
			authHeaders["oauth_callback"] = encodeURIComponent(callback);
		}

		if(instance.__secret.ACCESS_TOKEN) {
			authHeaders["oauth_token"] = instance.__secret.ACCESS_TOKEN;
		}

		authHeaders["oauth_signature"] = createSignature(instance, authHeaders, method, url, query);

		if (query) {
			requestURL += "?" + query;
		}
		
		authString += Object.keys(authHeaders).map(joinHeader.bind(null, authHeaders)).join(", ");

		request.open(method, requestURL);

		request.setRequestHeader("Authorization", authString);

		request.onreadystatechange = function () {
			if (request.status === 200 && request.readyState === 4) {
				var response = {},
				tokenRequestResponse = request.responseText.split("&");
				if(tokenRequestResponse.length == 3) {					
					callbackfunction("https://api.twitter.com/oauth/authorize?" + tokenRequestResponse[0]);

					alert("https://api.twitter.com/oauth/authorize?" + tokenRequestResponse[0]);

					response = tokenRequestResponse[0].split("=");
					instance.__secret["ACCESS_TOKEN"] = response[1];
					response = tokenRequestResponse[1].split("=");
					instance.__secret["ACCESS_TOKEN_SECRET"] = response[1];
				} else {
					alert("Access Granted!");
					response = tokenRequestResponse[0].split("=");
					instance.__secret.ACCESS_TOKEN = response[1];
					response = tokenRequestResponse[1].split("=");
					instance.__secret.ACCESS_TOKEN_SECRET = response[1];

					/* Set the local storage item */
					if ("localStorage" in window) 
					{
						localStorage.setItem("ACCESS_TOKEN", instance.__secret.ACCESS_TOKEN);
						localStorage.setItem("ACCESS_TOKEN_SECRET", instance.__secret.ACCESS_TOKEN_SECRET);
				        location.reload();
					} 
					else 
					{
						alert("no localStorage in window");
					}

				}
			}
		};

		request.send(data);
	}

	TwitterClient.prototype.requestToken = function (callbackfunction) {
		requestToken(this, "POST", "https://api.twitter.com/oauth/request_token", null, null, "oob", callbackfunction);
	}

	TwitterClient.prototype.requestAccess = function (pin, callbackfunction) {
		requestToken(this, "POST", "https://api.twitter.com/oauth/access_token", "oauth_verifier=" + pin, null, null, callbackfunction);
	}

	TwitterClient.prototype.findTweets = function (keyword, callback) {
		var query = keyword || HASHTAG;

		query = "q=" + encodeURIComponent(query);
		query += "&include_entities=true";

		makeRequest(this, "GET", "https://api.twitter.com/1.1/search/tweets.json", query, null, callback);
	};

	TwitterClient.prototype.myWall = function (callback) {
		makeRequest(this, "GET", "https://api.twitter.com/1.1/statuses/home_timeline.json", null, null, callback);
	};

	TwitterClient.prototype.tweet = function (content, callback) {
		makeRequest(this, "POST", "https://api.twitter.com/1.1/statuses/update.json", "include_entities=true&status=" + encodeURIComponent(content), null, callback);
	};

	window.TwitterClient = TwitterClient;

}());