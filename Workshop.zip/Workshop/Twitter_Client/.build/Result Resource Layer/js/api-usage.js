(function (TwitterClient) {

	var TC;
	
    var accessToken = localStorage.getItem("ACCESS_TOKEN");
    var accessTokenSecret = localStorage.getItem("ACCESS_TOKEN_SECRET");
	var processing = document.getElementById("ui-processing");
    processing.style.display='none';
	
    if(accessToken && accessTokenSecret) {
    	TC = new TwitterClient({
    			consumer_key: "0VoA7la9rDBLlZklhNmnFu2gD",
				consumer_secret: "uBPs3TvGCJVMhIWQptQbfW8aNQbLMYHT7nQlnSM5xaDFBvwc4B",
				access_token: accessToken,
				access_token_secret: accessTokenSecret
    	});
    	
    	var login = document.getElementById("login_container");
    	login.style.display='none';
    	var tweet = document.getElementById("tweet_container");
    	tweet.style.display='block';
    } else {
        var login = document.getElementById("login_container");
    	login.style.display='block';
    	var tweet = document.getElementById("tweet_container");
    	tweet.style.display='none';
    }
    
	function showTweets(tweets) {
		var target = document.getElementById("fetched-tweets"),
		statuses;
		target.innerHTML = "";
		var jsonData = JSON.parse(tweets);
		
		console.log(tweets);
		
		if (jsonData.statuses && jsonData.statuses.length > 0) {
			statuses = jsonData.statuses;
		} else if (Array.isArray(jsonData)) {
			statuses = jsonData;
		} else {
			statuses = [];
		}
		
		if (statuses.length > 0) {
			statuses.forEach(function (tweet) {
				var element = document.createElement("li");
				element.innerHTML = "<p>" + tweet.text + "</p><footer>@" + tweet.user.screen_name + " (" + tweet.user.name + ")</footer>";
				target.appendChild(element);
			});
			processing.style.display='none';
		} else {
			target.innerHTML = "No tweets returned";
		}
	}
	
	function success() {
		processing.style.display='none';
		alert("Tweet Sent!");
	}
	
	function removeLoading() {
		processing.style.display='none';
	}
	
	/** SAP Integration **/

	var SAAgent = null,
	SASocket = null,
	CHANNEL_ID = 104,
	ProviderAppName = "SamsungTwitterFeed";

	var agentCallback = {
			onconnect: function(socket) {
				console.log("agentCallback onconnect : " + socket);
				SASocket = socket;
				alert("Please unlock your phone and use it to complete Step 2.");
				SASocket.setSocketStatusListener(function(reason) {
					console.log("Service connection lost, Reason : " + reason);
					disconnect();
				});
			},
			onerror: function (err) {
				console.log("err [" + err.name + "] msg[" + err.message + "]");
				alert("Device not connected. Will display URL.");
			}
	}

	var peerAgentFindCallback = {
			onpeeragentfound: function(peerAgent) {
				try {
					if(peerAgent.appName === ProviderAppName) {
						console.log("peerAgentFindCallback: onpeeragentfound " + peerAgent.appName + " || " + ProviderAppName);
						SAAgent.setServiceConnectionListener(agentCallback);
						SAAgent.requestServiceConnection(peerAgent);
					} else {
						console.log("peerAgentFindCallback: onpeeragentfound else");
						alert("Not expected app! : " + peerAgent.appName);
					}
				} catch(err) {
					console.log("peerAgentFindCallback: onpeeragentfound exception [" + err.name + "] msg [" + err.message + "]");
				}
			},
			onerror: function (err) {
				console.log("err [" + err.name + "] msg[" + err.message + "]");
			}
	}
	
	function onsuccess(agents) {
		try {
			if(agents.length > 0) {
				SAAgent = agents[0];

				SAAgent.setPeerAgentFindListener(peerAgentFindCallback);
				SAAgent.findPeerAgents();
				console.log("onsuccess : " + SAAgent.name);
			} else {
				alert("Not found SAAgent!");
				console.log("onsuccess else");
			}
		} catch(err) {
			console.log("onsuccess exception [" + err.name + "] msg [" + err.message + "]");
		}
	}

	function disconnect() {
		try {
			if(SASocket != null) {
				console.log("DISCONNECT SASOCKET NOT NULL");
				SASocket.close();
				SASocket = null;
			}
		} catch(err) {
			console.log("DISCONNECT ERROR : exception : " + err.name + " message : " + err.message);
		}
	}
	
	function connect() {
		if(SASocket) {
			alert("Please unlock your phone and use it to complete Step 2.");
			return false;
		} 
		try {
			webapis.sa.requestSAAgent(onsuccess, function (err) {
				console.log("err [" + err.name + "] msg[" + err.message + "]");
			});
		} catch(err) {
			console.log("exception :" + err.name + " message : " + err.message);
		}
	}

	function fetch(sendString) {
	    processing.style.display='none';	
		try {
			SASocket.sendData(CHANNEL_ID, sendString);
		} catch(err) {
			console.log("exception : " + err.name + " message : " + err.message);
		}
	}

	function bindButtons() {
		var buttons = {
				requestTweetPage: document.getElementById("get-tweet-page"),
				getTweetsHashtag: document.getElementById("get-tweets-hashtag"),
				requestToken: document.getElementById("request-token"),
				requestAccessToken: document.getElementById("request-access-token"),
		},
		inputs = {
				tweetContent: document.getElementById("tweet-content"),
				tweetPIN: document.getElementById("token-pin")
		};

		buttons.requestToken.addEventListener("click", function () {
			TC = new TwitterClient({
				consumer_key: "0VoA7la9rDBLlZklhNmnFu2gD",
				consumer_secret: "uBPs3TvGCJVMhIWQptQbfW8aNQbLMYHT7nQlnSM5xaDFBvwc4B"
			});

			connect();
			processing.style.display='block';
			TC.requestToken(fetch);
		});
		

		buttons.requestAccessToken.addEventListener("click", function() {
			if(!TC) {
				alert("Please request your token first");
				return;
			}

			if(inputs.tweetPIN.value === "") {
				alert("Please request your token and generate PIN");
				return;
			}
			processing.style.display='block';
			TC.requestAccess(inputs.tweetPIN.value, removeLoading);
		})

		buttons.requestTweetPage.addEventListener("click", function() {
			if(!TC) {
				alert("Please add your keys first");
				return;
			}
			
			window.location = "TweetPage.html";
		}) 
			
		buttons.getTweetsHashtag.addEventListener("click", function () {
			if (!TC) {
				alert("Please add your keys first");
				return;
			}
			processing.style.display='block';
			TC.findTweets("#Samsung", showTweets);
		});
	}

	document.addEventListener("DOMContentLoaded", bindButtons);
}(window.TwitterClient));

window.onload = function () {
    // add eventListener for tizenhwkey
    document.addEventListener('tizenhwkey', function(e) {
        if(e.keyName == "back")
            tizen.application.getCurrentApplication().exit();
    });
};