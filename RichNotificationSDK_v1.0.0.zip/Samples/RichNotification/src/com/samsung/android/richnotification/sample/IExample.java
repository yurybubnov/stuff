package com.samsung.android.richnotification.sample;

import com.samsung.android.sdk.richnotification.SrnRichNotification;

public interface IExample {
    SrnRichNotification createRichNoti();
}
